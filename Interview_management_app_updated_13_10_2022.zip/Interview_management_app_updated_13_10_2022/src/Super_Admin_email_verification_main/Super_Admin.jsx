import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import style from './LogIn.module.css'

import laptop from './laptop.png'
// import './Otp.css'

const LogIn = () => {

    let navigate = useNavigate();

    const [values, setValues] = useState({
        email: ""
    });

    const [sendOtp, setSendOtp] = useState(false);

    var emailPattern = /^[^<>()[\]\\,;:\%#^\s@\"$&!@]+@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z0-9]+\.)+[a-zA-Z]{2,}))$/;

    const handleOtpSend = (e) => {
        e.preventDefault();

        if (values["email"] === '') {
            alert("Enter your email")
        } else if (!emailPattern.test(values["email"])) {
            alert("*Please enter valid email-ID.");
        } else {
            // fetch(`https://superadmin.shivila.co/send/`, {
            //     method: "POST",
            //     headers: {
            //         "Content-type": "application/json"
            //     },
            //     body: JSON.stringify(values)
            // }).then((res) => {
            //     if (res.ok) {
            //         alert(`otp send to your given email address`)
            //         setSendOtp(true)
            //         // navigate('/registerform', { replace: true })
            //     } else {
            //         alert(`${res.statusText}`)
            //     }
            // }).catch((err) => console.log(err))

            axios.post(`https://superadmin.shivila.co/send/`, values).then((res) => {
                if (res.status >= 200 && res.status < 300) {
                    alert(`otp send to your given email address`)
                    setSendOtp(true)
                } else {
                    alert(`${res.statusText}`)
                }
            }).catch((err) => console.log(err))
        }

    };

    var emailPattern = /^[^<>()[\]\\,;:\%#^\s@\"$&!@]+@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z0-9]+\.)+[a-zA-Z]{2,}))$/;

    const handleOtpVerify = (e) => {
        e.preventDefault();

        const body = { email: values.email, otp: e.target.otp.value }
        console.log(body);
        if (values["email"] === '') {
            alert("Enter your email")
        } else if (!emailPattern.test(values["email"])) {
            alert("*Please enter valid email-ID.");
        } else {

            // fetch(`https://superadmin.shivila.co/verify/`, {
            //     method: "POST",
            //     headers: {
            //         "Content-type": "application/json"
            //     },
            //     body: JSON.stringify(body)
            // }).then((res) => {
            //     if (res.ok) {
            //         alert(`Email verified`)
            //         navigate('/admin', { replace: true })
            //     } else {
            //         alert(`Something went worng`)
            //     }
            // }).catch((err) => console.log(err))

            axios.post(`https://superadmin.shivila.co/verify/`, values).then((res) => {
                if (res.status >= 200 && res.status < 300) {
                    alert(`Email verified`)
                    navigate('/admin', { replace: true })
                } else {
                    alert(`${res.statusText}`)
                }
            }).catch((err) => console.log(err))
        }


        // axios.post(`http://127.0.0.1:8000/verify/`, body)
        //     .then(res => {
        //         console.log(res.data);
        //         navigate('/registerform', { replace: true });
        //     })
        //     .catch(e => {
        //         console.log(e, e.data);
        //     });

        // navigate('/admin_dashboard', { replace: true });
    };

    function OTP() {
        return (
            <>
                <div className={style.page_body}>
                    <p className={style.admin_heading}>Welcome to Admin</p>
                    <div className={style.login_container}>
                        <form onSubmit={handleOtpVerify} className={style.otp_form}>
                            <input className={style.otpInput} type="text" name='otp' maxLength={6} required placeholder='Enter your OTP' />
                            <input id="get" type="submit" value="Submit" className={style.otp_button} />
                        </form>
                    </div>
                </div>
            </>
        )
    }

    const onChange = (e) => {
        setValues({ ...values, [e.target.name]: e.target.value })
    }


    return (
        <>
            {/* <img src={laptop}  className={style.image}/> */}
            <div className={style.page_body}>
                <div className={style.login_container}>
                    {/* <img src={admin_image} alt="" className={style.admin_image} /> */}
                    {sendOtp ? OTP() : (
                        <form className={style.login_form} onSubmit={handleOtpSend}>
                            <h1 className={style.login_form_heading}>Login</h1>
                            {/* <label className={style.login_form_label}>Email</label> */}
                            <input className={style.login_form_email_input} onChange={onChange} name="email" type="email" placeholder='  Enter your Email Id' required />
                            <input className={style.otp_button} type="submit" value="Get OTP" />
                        </form>
                    )}
                    <div>New admin? <Link to='/admin_reg'>Click Here</Link> or <span className="link">Go to <Link to='/'>home</Link></span></div>
                </div>
            </div>
        </>
    )
}

export default LogIn;
