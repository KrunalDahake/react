import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'

import style from './LogIn.module.css'

const Admin_registration = () => {

  const navigate = useNavigate()

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const handleRegistration = (e) => {
    e.preventDefault()

    var emailPattern = /^[^<>()[\]\\,;:\%#^\s@\"$&!@]+@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z0-9]+\.)+[a-zA-Z]{2,}))$/;

    if (email === '') {
      alert("Enter your email")
    }
    else if (!emailPattern.test(email)) {
      alert("*Please enter valid email-ID.");
    } else if (password === '') {
      alert("Enter your password")
    } else {
      fetch(`https://superadmin.shivila.co/register/`, {
        method: "POST",
        headers: {
          'Content-type': 'application/json'
        },
        body: JSON.stringify({ email, password })
      }).then((res) => {
        if (res.ok) {
          alert("Registered Successfully")
          navigate('/admin_login', { replace: true })
        }
      })
        .catch((err) => console.log(err))
    }
  }

  const [showPassword, setShowPassword] = useState(false)

  const togglePassword = () => {
    setShowPassword(!showPassword)
  }
  return (
    <>
      <div className={style.page_body}>
        <p className={style.admin_heading}>Admin Registration</p>
        <div className={style.login_container}>
          <form className={style.login_form} onSubmit={handleRegistration}>
            <input type="email" name="" id={style.emailInput} className={style.login_form_email_input} onChange={(e) => setEmail(e.target.value)} placeholder='Enter your email address' />

            <div className={style.passwordBox}>
              <input type={showPassword ? "text" : "password"} name="" id={style.passInput} className={style.login_form_email_input} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" />
              <span onClick={togglePassword} className={style.eyeBtn}>{showPassword ? <i class="fa-solid fa-eye"></i> : <i class="fa-solid fa-eye-slash"></i>}</span>
            </div>
            <input type="submit" value="Register" className={style.otp_button} />
          </form>
          <p className="link">Already have account? <Link to='/admin_login'>click here!</Link> or <span className="link">Go to <Link to='/'>home</Link></span></p>

        </div>
      </div>
    </>
  )
}

export default Admin_registration