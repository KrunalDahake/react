import React from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

const OTP_verify = () => {
    const navigate = useNavigate()

    const [email, setEmail] = useState('')
    const [otp, setOtp] = useState('')

    const submit = (e) => {
        e.preventDefault()

        fetch(`http://127.0.0.1:8000/verify/`, {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify({ email, otp })
        }).then((res) => {
            if (res.ok) {
                alert(`Email verified`)
                // navigate('/registerform', { replace: true })
            }else{
                alert(`${res.statusText}`)
            }
        }).catch((err) => console.log(err))

        console.log()
        // navigate('/registerform')
    }
    return (
        <>
            <form onSubmit={submit}>
                <input type="email" name="email" id="email" onChange={(e) => setEmail(e.target.value)} />
                <input type="text" name='otp' id='otp' onChange={(e) => setOtp(e.target.value)}  />
                <input type="submit" value="Submit" />
            </form>
        </>
    )
}

export default OTP_verify