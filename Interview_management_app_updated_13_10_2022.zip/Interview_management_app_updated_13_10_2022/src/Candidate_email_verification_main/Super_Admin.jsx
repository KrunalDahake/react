import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import style from './LogIn.module.css'

// Import image
import image from './candidate_verification.png'
// import admin_image from './admin_login_image.png'
// import './Otp.css'

const Candidate_login = () => {

    let navigate = useNavigate();

    const [values, setValues] = useState({
        email: ""
    });

    const [sendOtp, setSendOtp] = useState(false);

    const handleOtpSend = (e) => {
        e.preventDefault();
        console.log(values);
        // fetch(`https://candidate.shivila.co/candidate-register/`, {
        //     method: "POST",
        //     headers: {
        //         "Content-type": "application/json"
        //     },
        //     body: JSON.stringify(values)
        // }).then((res) => {
        //     if (res.ok) {
        //         alert(`OTP send to your given email address`)
        //         setSendOtp(true)
        //         // navigate('/registerform', { replace: true })
        //     } else {
        //         alert(`Given email address is already registered. Try with different email address `)
        //     }
        // }).catch((err) => console.log(err))


        axios.post(`https://candidate.shivila.co/candidate-register/`, values).then((res) => {
            if (res.status >= 200 && res.status < 300) {
                alert(`OTP send to your given email address`)
                setSendOtp(true)
            } else {
                alert(`Given email address is already registered. Try with different email address `)
            }
        }).catch((err) => console.log(err))



        // axios.post(`http://127.0.0.1:8000/send/`, values).then((res) => {
        //     if (res.ok) {
        //         console.log(res.data);
        //         setSendOtp(true)
        //         alert(`done`)
        //     }
        // }).catch(e => {
        //     console.log(e, e.data);
        // });

        // navigate('/admin_dashboard')

    };


    const handleOtpVerify = (e) => {
        e.preventDefault();

        const body = { email: values.email, otp: e.target.otp.value }
        console.log(body);

        // fetch(`https://candidate.shivila.co/candidate-varify/`, {
        //     method: "POST",
        //     headers: {
        //         "Content-type": "application/json"
        //     },
        //     body: JSON.stringify(body)
        // }).then((res) => {
        //     if (res.ok) {
        //         alert(`Email verified`)
        //         navigate('/registerform', { replace: true })
        //     } else {
        //         alert(`Something went wrong`)
        //     }
        // }).catch((err) => console.log(err))


        axios.post(`https://candidate.shivila.co/candidate-varify/`, body)
            .then((res) => {
                // console.log(res.data);
                if (res.status >= 200 && res.status < 300) {
                    alert(`Email verified`)
                    navigate('/registerform', { replace: true })
                } else {
                    alert(`Something went wrong`)
                }
            }).catch((e) => {
                console.log(e, e.data);
            });

        // navigate('/admin_dashboard', { replace: true });
    };

    function OTP() {
        return (
            <>
                {/* <div className={style.admin_login_main_container}>
                    <h1 style={{ textAlign: "center", fontFamily: 'Arial, Helvetica, sans-serif', }}>OTP Verification</h1>
                    <form onSubmit={handleOtpVerify} className={style.otp_form}>
                        <input className={style.otpInput} type="text" name='otp' maxLength={6} required placeholder='Enter your OTP' />
                        <input id="get" type="submit" value="Submit" className={style.otp_button} />
                    </form>
                </div> */}
                <div className={style.main_container}>
                    <p className={style.candidate_email_form_heading}>Welcome to candidate verification</p>
                    <form onSubmit={handleOtpVerify} className={style.candidate_email_form_container}>
                        <img src={image} alt="" className={style.candidate_email_form_image} />
                        <div className={style.candidate_email_form_control}>
                            <input type="email" name="email" id="email" className={style.candidate_form_control} />
                            <input type="text" name="otp" placeholder='Enter OTP' id={style.otp} className={style.candidate_form_control} maxLength={6} />
                            <input type="submit" value="Submit" className={style.submit_button} /><br />
                            <p>Go to <Link to='/'>Home</Link></p>
                        </div>
                    </form>
                </div>
            </>
        )
    }

    const onChange = (e) => {
        setValues({ ...values, [e.target.name]: e.target.value })
    }


    return (
        <>
            <div className={style.login_container}>
                {/* <img src={admin_image} alt="" className={style.admin_image} /> */}
                {sendOtp ? OTP() : (
                    // <form className={style.login_form} onSubmit={handleOtpSend}>
                    //     <h1 className={style.login_form_heading}>Login</h1>
                    //     <input className={style.login_form_email_input} onChange={onChange} name="email" type="email" placeholder='  Enter your Email Id' required />
                    //     <input className={style.otp_button} type="submit" value="Get OTP" />
                    // </form>
                    <div className={style.main_container}>
                        <p className={style.candidate_email_form_heading}>Welcome to candidate verification</p>
                        <form onSubmit={handleOtpSend} className={style.candidate_email_form_container}>
                            <img src={image} alt="" className={style.candidate_email_form_image} />
                            <div className={style.candidate_email_form_control}>
                                <input type="email" name="email" id="link" className={style.candidate_form_control} placeholder='Enter your valid email address' onChange={onChange} />
                                <input type="submit" value="Submit" className={style.submit_button} /> <br />
                                <p>Go to <Link to='/'>Home</Link></p>
                            </div>
                        </form>

                    </div>
                )}
            </div>
        </>
    )
}

export default Candidate_login;
