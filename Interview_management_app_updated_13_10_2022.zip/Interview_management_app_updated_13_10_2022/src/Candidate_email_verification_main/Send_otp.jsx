import React from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

const Send_otp = () => {
    const navigate = useNavigate()
    const [email, setEmail] = useState('')

    const submit = (e) => {
        e.preventDefault()
        // console.log(email)
        fetch(`http://127.0.0.1:8000/send/`, {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify({ email })
        }).then((res) => {
            if (res.ok) {
                alert(`otp send to your given email address`)
                navigate('/verification', )
            }else{
                alert(`${res.statusText}`)
            }
        }).catch((err) => console.log(err))
    }
    return (
        <>
            <form onSubmit={submit}>
                <input type="email" name="email" id="email" onChange={(e) => setEmail(e.target.value)} />
                <input type="submit" value="Submit" />
            </form>
        </>
    )
}

export default Send_otp;