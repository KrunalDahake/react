import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom';
import style from './Candidate_details_page.module.css'
import { FaCopy } from 'react-icons/fa'
import { CSVLink, CSVDownload } from 'react-csv'


const Interviewer_link = (props) => {
    return (
        <>
            <p className={style.interviewer_name}>{props.name} ({props.domain}):- <span ><a href={props.link} className={style.interviewer_link} target="blank"> {props.link}</a></span></p>
        </>
    )
}

const Interviewer_availability = () => {

    const text = "https://interview-candidate-registration.netlify.app/"

    const Popup = () => {
        // var popup = document.getElementById("myPopup");
        // popup.classList.toggle();
        alert("Copied link to your clipboard")
    }
    // get taken interview student Data
    // const candidateUrl = `https://interviewmanagement.shivila.co/candidate-detail/candidate/`;
    // const [candidateData, setCandidateData] = useState([])

    // const fetchData = async (candidateUrl) => {
    //     try {
    //         const response = await fetch(candidateUrl);
    //         const data = await response.json() 
    //         // console.log(data)
    //         setCandidateData(data)
    //     } catch (error) {
    //         console.log(error)
    //     }
    // }

    // useEffect(() => {
    //     setInterval(() => {
    //         fetchData(candidateUrl)
    //     }, 900)
    // }, [])

    // const selected_candidates = candidateData.filter((data) => data.status === 'Selected')
    // const not_selected_candidate = candidateData.filter((data) => data.status === 'Not Selected')
    // const not_judge_candidate = candidateData.filter((data) => data.status === 'Not Judge')
    // const need_second_round = candidateData.filter((data) => data.status === 'Need Second Round')
    // console.log(need_second_round)

    // className={style.previous_page_btn2}

    // const [modalOpen, setModalOpen] = useState(false)


    // const candidateDeleteHandeler = (id) => {

    //     fetch(`https://interviewmanagement.shivila.co/candidate-detail/candidate/${id}/`, {
    //         method: "DELETE",
    //         headers: {
    //             "Content-type": 'application/json',
    //         }
    //     })
    //         .then((res) => {
    //             if (res.ok) {
    //                 alert(`${id} no Candidate deleted successfully`)
    //             } else {
    //                 alert(`ERROR:- ${res.status}`)
    //             }
    //         })
    //         .catch((err) => console.log(err))
    // }



    const [interviewerDetails, setInterviewerDetails] = useState([])

    const url = `https://interviewmanagement.shivila.co/interviewee-reg/register/`;
    // const url = `http://127.0.0.1/interviewee-reg/register/`;
    const fetchData2 = async (url) => {
        try {
            const response = await fetch(url);
            const data = await response.json()
            // console.log(data)
            setInterviewerDetails(data)
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        setInterval(() => {
            fetchData2(url)
        }, 1000)
    }, [])


    const navigate = useNavigate()

    const logoutHandeler = () => {
        localStorage.removeItem('lobby_team');
        navigate('/')
    }

    const [regCandData, setRegCandData] = useState([])

    const regCandUrl = `https://candidate.shivila.co/candidate-enrollment/Enrollment/`;
    const fetchCandidate = async (regCandUrl) => {
        try {
            const response = await fetch(regCandUrl);
            const data = await response.json();
            // console.log(data);
            setRegCandData(data)
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        setInterval(() => {
            fetchCandidate(regCandUrl)
        }, 1000)
    }, [])






    return (
        <>
            <div className={style.button_box}>
                <p className={style.interviewerName}>Welcome to Lobby</p>
                <button className={style.logout_btn} onClick={logoutHandeler}>Logout</button>
            </div>
            <p className={style.interviewdetails}>Interviewer Details</p>


            <div className={style.line}>
                <p className={style.noteBelow}>**Candidate must fillup this form:- <a className={style.candidate_link} href="http://localhost:3000/candidate_login" target='blank'>http://localhost:3000/candidate_login</a></p>
                <button className={style.copy} onClick={() => {
                    navigator.clipboard.writeText(text);
                }}>
                    <i className={style.icon} onClick={Popup}>
                        <FaCopy />
                    </i>
                </button>
            </div>

            <div className={style.link_box}>
                <p className={style.link_box_heading}>****Interviewer Link****</p>
                <ol>
                    <li className={style.interviewer_link_li}><Interviewer_link name="Sayantan Haldar & Kamalika Jash" domain="Frontend-Web(Html/Css/JS/React)" link="https://meet.google.com/cxo-fnoh-skq " /></li>
                    <li className={style.interviewer_link_li}><Interviewer_link name="Debanka Das & Suraj Mahakud" domain="Backend-Web(Python, Django)" link=" https://meet.google.com/sug-mfjs-sgz" /></li>
                    <li className={style.interviewer_link_li}><Interviewer_link name="Md Khalid" domain="Backend-Web(Python, Django)" link="https://meet.google.com/bhx-hfuw-vqh" /></li>
                    <li className={style.interviewer_link_li}><Interviewer_link name="Manjeet Yadav & Topinder Chettri" domain="Backend-Web(Python, Django)" link="https://meet.google.com/wwn-njby-srx" /></li>
                    <li className={style.interviewer_link_li}><Interviewer_link name="Arpan Chakraborty" domain="PHP/SEO/Digital Marketing/DevOps" link="https://meet.google.com/doh-pqcw-tyu" /></li>
                    <li className={style.interviewer_link_li}><Interviewer_link name="Abhishek Rai" domain="Java-Dev" link="https://meet.google.com/vxo-ogcn-mqe" /></li>
                    <li className={style.interviewer_link_li}><Interviewer_link name="Sunil Kumar" domain="Java-Dev" link="https://meet.google.com/gqd-njzi-zvi" /></li>
                </ol>
            </div>
            <div className={style.candidate_table_container}>
                <table className={style.candidate_table}>
                    <thead className={style.candidate_table_head}>
                        <tr className={style.candidate_table_tr}>
                            <th className={style.candidate_table_th}>Interviewer Name</th>
                            <th className={style.candidate_table_th} id={style.interviewerEmail}>Interviewer Link</th>
                            <th className={style.candidate_table_th}>Interviewer Domain</th>
                            <th className={style.candidate_table_th}>Interviewer status</th>
                        </tr>
                    </thead>
                    <tbody className={style.candidate_table_tbody}>
                        {
                            interviewerDetails.map((data, index) => (
                                <tr className={style.candidate_table_tr2} key={index} >
                                    <td className={style.candidate_table_td} >{data.name}</td>
                                    <td className={style.candidate_table_td} id={style.interviewerEmail}><a href={data.interviewer_link} target="blank">{data.interviewer_link}</a></td>
                                    <td className={style.candidate_table_td}>{data.designation}</td>
                                    <td className={style.candidate_table_td} id={style.status_table} style={data.status === '0' ? {background:'rgb(218, 248, 143)'} : data.status === '1' ? {background:'rgb(255, 80, 80)'} : {background:'aliceblue'}}>{data.status === '0' ? <span className={style.available}>Available <i class="fa-solid fa-check"></i></span> : data.status === '1' ? <span className={style.busy}>Busy <i class="fa-solid fa-circle"></i></span> : <span className={style.offline}>Offline <i class="fa-solid fa-xmark"></i></span>}</td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>
            </div>

            <p className={style.interviewdetails}>Candidate Details</p>
            <div className={style.candidate_table_container}>
                <table className={style.candidate_table}>
                    <thead className={style.candidate_table_head}>
                        <tr className={style.candidate_table_tr}>
                            <th className={style.candidate_table_th}>Image</th>
                            <th className={style.candidate_table_th}>Name</th>
                            <th className={style.candidate_table_th} id={style.dob}>DOB</th>
                            <th className={style.candidate_table_th}>Father's Name</th>
                            <th className={style.candidate_table_th}>Mother's Name</th>
                            <th className={style.candidate_table_th}>Email</th>
                            <th className={style.candidate_table_th}>Mobile Number</th>
                            <th className={style.candidate_table_th}>Whatsapp Number</th>
                            <th className={style.candidate_table_th}>Domain</th>
                            <th className={style.candidate_table_th}>Specialization</th>
                        </tr>
                    </thead>
                    <tbody className={style.candidate_table_tbody}>
                        {
                            regCandData.map((data, index) => (
                                <tr className={style.candidate_table_tr2} key={index}>
                                    <td className={style.candidate_table_td}><img className={style.candidate_image} src={data.image} alt="Candidate_Image" /></td>
                                    <td className={style.candidate_table_td}>{data.name_of_the_candidate}</td>
                                    <td className={style.candidate_table_td} id={style.dob}>{data.date_of_birth}</td>
                                    <td className={style.candidate_table_td}>{data.father_name}</td>
                                    <td className={style.candidate_table_td}>{data.mother_name}</td>
                                    <td className={style.candidate_table_td}>{data.email}</td>
                                    <td className={style.candidate_table_td}>{data.phone_number}</td>
                                    <td className={style.candidate_table_td}>{data.wp_number}</td>
                                    <td className={style.candidate_table_td}>{data.applied_domain}</td>
                                    <td className={style.candidate_table_td}>{data.specilization}</td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>
            </div>

            <div className={style.download_box_for_candidate}>
                <CSVLink data={regCandData} className={style.previous_page_btn2} id={style.download_candidate_list}><i class="fa-solid fa-download"></i>&nbsp;  Complete Candidate List</CSVLink>
            </div>

        </>
    )
}

export default Interviewer_availability