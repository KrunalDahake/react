import React from "react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import styles from '../Lobby/Lobby_register.module.css'
import girl from "./girl.png";

const Lobby_register = () => {


  const navigate = useNavigate()

  const [values, setValues] = useState({
    full_name: '',
    email: '',
    password: '',
    password2: '',
  });

  const { full_name, email, password, password2 } = values;

  const onChangeRegister = (e) => {
    const newValues = { ...values }
    newValues[e.target.name] = e.target.value
    setValues(newValues)
  }

  const handleRegisterSubmit = (e) => {
    e.preventDefault()
    const data = { full_name, email, password, password2 }
    const loginUrl = `https://lobby.shivila.co/lobby-accounts/api/register/`;

    var emailPattern = /^[^<>()[\]\\,;:\%#^\s@\"$&!@]+@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z0-9]+\.)+[a-zA-Z]{2,}))$/;


    if (full_name === '') {
      alert("Enter your name")
    } else if (!full_name.match(/^[A-Za-z][A-Za-z_ ]{7,29}$/)) {
      alert("*Please enter alphabet characters only in your name.")
    } else if (email === '') {
      alert("Enter your email")
    } else if (!emailPattern.test(email)) {
      alert("*Please enter valid email-ID.");
    } else if (password !== password2) {
      alert("**Passwords are not same. Please enter same password")
    } else {
      fetch(loginUrl, {
        method: "POST",
        headers: {
          "Content-type": "application/json"
        },
        body: JSON.stringify(data)
      }).then((res) => {
        navigate('/lobby_login')
        alert("Register Successfully")
      }).catch((err) => {
        alert("Something wrong")
      })
    }
    // console.log(full_name, email, password, password2)
    setValues({
      full_name: '',
      email: '',
      password: '',
      password2: ''
    })
  }


  const [showPassword, setShowPassword] = useState(false)

  const togglePassword = () => {
    setShowPassword(!showPassword)
  }
  const [showPassword2, setShowPassword2] = useState(false)

  const togglePassword2 = () => {
    setShowPassword2(!showPassword2)
  }


  return (
    <>
      <div className={styles.lobby_heading_box}>
        <p className={styles.registration_heading}>Welcome to Lobby</p>
        <button className={styles.goto_home} onClick={() => navigate('/')} ><i class="fa-solid fa-arrow-left"></i> <span className={styles.back}>Back</span></button>
      </div>
      <div className={styles.register_page}>
        <form onSubmit={handleRegisterSubmit} className={styles.register_form}>
          <p className={styles.sub_heading}>Register Yourself</p>
          <div className={styles.register_form_subcontainer}>
            <img src={girl} alt="" className={styles.login_image} />
            <div className={styles.register_input_container}>
              <input
                type="text"
                name="full_name"
                value={full_name}
                placeholder="Enter your name"
                onChange={onChangeRegister}
                className={styles.form_input}
                required
              />
              <input
                type="email"
                name="email"
                value={email}
                placeholder="Enter your email"
                onChange={onChangeRegister}
                className={styles.form_input}
                required
              />
              <div className={styles.passBox}>
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  value={password}
                  placeholder="Enter your password"
                  onChange={onChangeRegister}
                  className={styles.form_input}
                  required
                />
                <span onClick={togglePassword} className={styles.eyeBtn}>{showPassword ? <i class="fa-solid fa-eye"></i> : <i class="fa-solid fa-eye-slash"></i>}</span>
              </div>
              <div className={styles.passBox}>
                <input
                  type={showPassword2 ? "text" : "password"}
                  name="password2"
                  value={password2}
                  placeholder="Rewrite your password"
                  onChange={onChangeRegister}
                  className={styles.form_input}
                  required
                />
                <span onClick={togglePassword2} className={styles.eyeBtn}>{showPassword2 ? <i class="fa-solid fa-eye"></i> : <i class="fa-solid fa-eye-slash"></i>}</span>
              </div>

              <input type="submit" value="Register" className={styles.submit_register} />
              <p className={styles.last_registration_form_line}>Already have account? <Link to='/lobby_login' className={styles.goto_login} >click here!</Link></p>
            </div>
          </div>
        </form>
      </div>
    </>
  );
};

export default Lobby_register;

