import React from "react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import girl2 from "./girl2.png";
import styles from "./Lobby_register.module.css";

const Lobby_login = () => {
  const [loginData, setLoginData] = useState({
    email: '',
    password: ''
  })

  const { email, password } = loginData;

  const loginOnchange = (e) => {
    const newData = { ...loginData };
    newData[e.target.name] = e.target.value;
    setLoginData(newData)
  }

  const loginSubmit = (e) => {
    e.preventDefault()

    const data = {
      email, password
    }
    console.log(data)

    setLoginData({
      email: '',
      password: ''
    })

    const loginUrl = `https://lobby.shivila.co/lobby-accounts/api/login/`;
    fetch(loginUrl, {
      method: "POST",
      headers: {
        "Content-type": "application/json"
      },
      body: JSON.stringify(data)
    })
      .then((res) => {
        if (res.ok) {
          alert(`User Login successFully`)
          navigate('/register_interviewer')
          localStorage.setItem('lobby_team', JSON.stringify(data))
        } else {
          alert(`Invalid Credients`)
          navigate('/lobby_login')
        }
      })
      .catch((err) => console.log(err))
  }

  const navigate = useNavigate()

  const [showPassword, setShowPassword] = useState(false)
  

  const togglePassword = () => {
    setShowPassword(!showPassword)
  }
  

  return (
    <>
      <div className={styles.lobby_heading_box}>
        <p className={styles.registration_heading}>Welcome to Lobby</p>
        <button className={styles.goto_home} onClick={() => navigate('/')} ><i class="fa-solid fa-arrow-left"></i> <span className={styles.back}>Back</span></button>
      </div>
      <div className={styles.register_page}>
        <form onSubmit={loginSubmit} className={styles.register_form}>
          <p className={styles.sub_heading}>Login Yourself</p>
          <div className={styles.register_form_subcontainer}>
            <img src={girl2} alt="" className={styles.login_image} />
            <div className={styles.register_input_container}>
              <input
                type="email"
                name="email"
                value={email}
                placeholder="Enter your email"
                onChange={loginOnchange}
                className={styles.form_input}
              />
              <div className={styles.passBox}>
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  value={password}
                  placeholder="Enter your password"
                  onChange={loginOnchange}
                  className={styles.form_input}
                />
                <span onClick={togglePassword} className={styles.eyeBtn}>{showPassword ? <i class="fa-solid fa-eye"></i> : <i class="fa-solid fa-eye-slash"></i>}</span>
              </div>
              <input
                type="submit"
                value="Login"
                className={styles.submit_register}
              />
              <p className={styles.last_registration_form_line}>
                Don't have account?{" "}
                <Link to="/lobby_register" className={styles.goto_login}>
                  click here!
                </Link>
              </p>
            </div>
          </div>
        </form>
      </div>
    </>
  );
};

export default Lobby_login;
