import axios from 'axios';
import React, { Component } from 'react'
import { Link, Navigate } from 'react-router-dom';
import style from './Thankyou.module.css'

export class NotFound404 extends Component {
    constructor() {
        super();
        this.state = {
            joke: ''
        };
    }

    componentDidMount() {
        axios.get('https://v2.jokeapi.dev/joke/Any?type=single')
            .then((res) => {
                this.setState({ joke: res.data.joke });
            });
    }

    render() {
        return (
            <>
                <div className={style.error_container}>
                    <div className={style.lost}>Lost? &#129300;</div>
                    <div className={style.joke1}>Enjoy the following joke, take a breath and return <Link className={style.home_btn} to='/'>home</Link></div>
                    <div className={style.main_joke}>{this.state.joke}</div>
                </div>
            </>
        )
    }
}

export class NotFound extends Component {
    render() {
        return (
            <>
                <Navigate to='/404' replace={true} />
            </>
        )
    }
}
export default NotFound404;