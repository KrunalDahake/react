import React from 'react'
import style from './Thankyou.module.css'
import right from './right.png'


const Thankyou = () => {
  return (
    <div className={style.main}>
      <h1 className={style.heading}>Thank You!</h1>
      <h3 className={style.para}>Have a Nice Day</h3>
      {/* <img src={right} alt="" /> */}
      <br />
      <br />
      <center><img src={right} alt="centered image" height="250" width="250"/> </center>
    </div>
  )
}

export default Thankyou;
