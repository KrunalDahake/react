import React, { Component } from 'react'

// Import css
import style from "./Candidate.module.css";
import candidateFormImage from './candidate_form.png'

export default class New_Canididate_form extends Component {
    constructor(props) {
        super(props)

        this.state = {
            name_of_the_candidate: '',
            date_of_birth: '',
            email: '',
            phone_number: '',
            wp_number: '',
            applied_domain: '',
            specilization: '',
            father_name: '',
            mother_name: '',
            image: {},
        }
        this.image = this.imageHandeler.bind(this);
        this.handleCandidateDetails = this.handleCandidateDetails.bind(this);
    }


    imageHandeler(event) {
        this.setState({ image: event.target.files[0] })
    }

    // imageHandeler(event) {
    //     this.setState({ image: event.target.files[0] });
    // }

    handleCandidateDetails(e) {
        e.preventDefault()
        let formData = new FormData();

        formData.append('name_of_the_candidate', this.state.name_of_the_candidate);
        formData.append('date_of_birth', this.state.date_of_birth);
        formData.append('email', this.state.email);
        formData.append('phone_number', this.state.phone_number);
        formData.append('wp_number', this.state.wp_number);
        formData.append('applied_domain', this.state.applied_domain);

        formData.append('specilization', this.state.specilization);
        formData.append('father_name', this.state.father_name);

        formData.append('mother_name', this.state.mother_name);
        formData.append('image', this.state.image);

        console.log(formData)

        fetch(`https://candidate.shivila.co/candidate-enrollment/Enrollment/`, {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(formData)

        }).then((res) => {
            if (res.ok) {
                alert("Submit successfully")
            }
            else {
                alert("Something wents wrong")
            }
        }).catch((err) => {
            console.log(err)
        })
    }
    render() {
        return (
            <>
                <p className={style.candidate_page_heading}>Candidate registration</p>
                <div className={style.main_container}>
                    <form onSubmit={this.handleCandidateDetails} className={style.candidate_form}>
                        <img src={candidateFormImage} alt="" className={style.candidate_form_image} />
                        <div className={style.candidate_form_sub_container}>
                            <div className={style.label_box}>
                                <input
                                    type="text"
                                    name="name_of_the_candidate"
                                    id=""
                                    value={this.state.name_of_the_candidate}
                                    placeholder="Enter your name"
                                    onChange={(e) => this.setState({ name_of_the_candidate: e.target.value })}
                                    className={style.form_control}
                                />
                            </div>
                            <div className={style.label_box}>
                                <input
                                    type="file"
                                    name="candidateImage"
                                    id=""
                                    // placeholder="Enter your name"
                                    onChange={this.image}
                                    className={style.form_control}
                                />
                            </div>
                            <div className={style.label_box}>
                                <input
                                    type="text"
                                    name="father_name"
                                    id=""
                                    value={this.state.father_name}
                                    placeholder="Enter your father name"
                                    onChange={(e) => this.setState({ father_name: e.target.value })}
                                    className={style.form_control}
                                />
                            </div>
                            <div className={style.label_box}>
                                <input
                                    type="text"
                                    name="mother_name"
                                    id=""
                                    value={this.state.mother_name}
                                    placeholder="Enter your mother name"
                                    onChange={(e) => this.setState({ mother_name: e.target.value })}
                                    className={style.form_control}
                                />
                            </div>
                            <div className={style.label_box}>
                                <input
                                    type="date"
                                    name="date_of_birth"
                                    id=""
                                    value={this.state.date_of_birth}
                                    placeholder="Enter your date of birth"
                                    onChange={(e) => this.setState({ date_of_birth: e.target.value })}
                                    className={style.form_control}
                                />
                            </div>
                            <div className={style.label_box}>
                                <input
                                    type="email"
                                    name="email"
                                    id=""
                                    value={this.state.email}
                                    placeholder="Enter your email"
                                    onChange={(e) => this.setState({ email: e.target.value })}
                                    className={style.form_control}
                                />
                            </div>
                            <div className={style.label_box}>
                                <input
                                    type="number"
                                    name="phone_number"
                                    id=""
                                    value={this.state.phone_number}
                                    placeholder="Enter your number"
                                    onChange={(e) => this.setState({ phone_number: e.target.value })}
                                    className={style.form_control}
                                />
                            </div>
                            <div className={style.label_box}>
                                <input
                                    type="number"
                                    name="wp_number"
                                    value={this.state.wp_number}
                                    placeholder="Enter your whatsapp number"
                                    onChange={(e) => this.setState({ wp_number: e.target.value })}
                                    className={style.form_control}
                                />
                            </div>
                            <div className={style.label_box}>
                                <input
                                    type="text"
                                    name="applied_domain"
                                    value={this.state.applied_domain}
                                    placeholder="Enter which domain you are applied"
                                    onChange={(e) => this.setState({ applied_domain: e.target.value })}
                                    className={style.form_control}
                                />
                            </div>
                            <div className={style.label_box}>
                                <input
                                    type="text"
                                    name="specilization"
                                    value={this.state.specilization}
                                    placeholder="e.g html, css, JS, Java, php"
                                    onChange={(e) => this.setState({ specilization: e.target.value })}
                                    className={style.form_control}
                                />
                            </div>
                            <div className={style.label_box}>
                                <input
                                    type="submit"
                                    value="Submit"
                                    className={style.submit_candidates_btn}
                                />
                            </div>
                        </div>
                    </form>
                </div>
            </>
        )
    }
}
