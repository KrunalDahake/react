import axios from 'axios'
import React from 'react'
import { useState } from 'react'

const Demo_form = () => {

const [name_of_the_candidate, setName] = useState('')

const [image, setFile] = useState('')

const [date_of_birth, setDob] = useState('')

const [email, setEmail] = useState('')

const [father_name, setFather_name] = useState('')

const [mother_name, setMother_name] = useState('')

const [phone_number, setPhone_number] = useState('')

const [wp_number, setWp_number] = useState('')

const [applied_domain, setApplied_domain] = useState('')

const [specilization, setSpecilization] = useState('')


const handleSubmit = (e) => {
    e.preventDefault()
     
    let formData = new FormData();

    formData.append('image', image);
    formData.append('name_of_the_candidate', name_of_the_candidate);
    formData.append('date_of_birth', date_of_birth);
    formData.append('father_name', father_name);
    formData.append('mother_name', mother_name);
    formData.append('phone_number', phone_number);
    formData.append('wp_number', wp_number);
    formData.append('applied_domain', applied_domain);
    formData.append('specilization', specilization);
    formData.append('email', email);

    console.log(formData);

    // formData.append("image", image);

    axios.post(`http://127.0.0.1:8000/candidate-enrollment/Enrollment/`, formData).then(res  => console.log(res))
    .catch(err => console.log(err))
}

  return (
    <div>
        <form onSubmit={handleSubmit}>
            <input type="text" name="" id="" placeholder='Enter your name' onChange={(e) => setName(e.target.value)}/>
            <input type="file" name="" id="" onChange={(e) => setFile(e.target.files[0])}/>
            <input type="date" name="" id="" placeholder='Enter your Date of Birth' onChange={(e) => setDob(e.target.value)}/>
            <input type="text" name="" id="" placeholder='Enter your father name' onChange={(e) => setFather_name(e.target.value)}/>
            <input type="text" name="" id="" placeholder='Enter your mother name' onChange={(e) => setMother_name(e.target.value)}/>
            <input type="email" name="" id="" placeholder='Enter your email id' onChange={(e) => setEmail(e.target.value)}/>
            <input type="number" name="" id="" placeholder='Enter your phone number' onChange={(e) => setPhone_number(e.target.value)}/>
            <input type="number" name="" id="" placeholder='Enter your Whatsapp number' onChange={(e) => setWp_number(e.target.value)}/>
            <input type="text" name="" id="" placeholder='Enter your domain' onChange={(e) => setApplied_domain(e.target.value)}/>
            <input type="text" name="" id="" placeholder='Enter your domain skills' onChange={(e) => setSpecilization(e.target.value)}/>
            <input type="submit" value="Submit" />
        </form>
    </div>
  )
}

export default Demo_form