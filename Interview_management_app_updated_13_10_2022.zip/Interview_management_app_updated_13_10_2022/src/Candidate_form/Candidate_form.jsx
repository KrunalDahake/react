import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import { generatePath, useNavigate } from "react-router-dom";
import axios from "axios";
// Import css
import style from "./Candidate.module.css";
import candidateFormImage from './candidate_form.png'


const Candidate_register_form = () => {

  let navigate = useNavigate();

  const [name_of_the_candidate, setName] = useState('')
  const [image, setFile] = useState('')
  const [date_of_birth, setDob] = useState('')
  const [email, setEmail] = useState('')
  const [father_name, setFather_name] = useState('')
  const [mother_name, setMother_name] = useState('')
  const [phone_number, setPhone_number] = useState('')
  const [wp_number, setWp_number] = useState('')
  const [applied_domain, setApplied_domain] = useState('')
  const [specilization, setSpecilization] = useState('')
  const [age, SetAge] = useState('')



  const [registerCanidate, setRegisterCandidate] = useState([])


  const url = `https://candidate.shivila.co/candidate-enrollment/Enrollment/`

  const fetchData = async (url) => {
    try {
      const response = await fetch(url);
      const data = await response.json()
      // console.log(data)
      setRegisterCandidate(data)
    } catch (error) {
      console.log(error)
    }

  }

  useEffect(() => {
    fetchData(url)
  }, []);

  const candidate = registerCanidate.filter((candidate) => candidate.email === email);
  const candidateEmail = candidate.map((mail) => mail.email)[0]

  const handleSubmit = (e) => {
    e.preventDefault()

    let formData = new FormData();

    formData.append('image', image);
    formData.append('name_of_the_candidate', name_of_the_candidate);
    formData.append('date_of_birth', date_of_birth);
    formData.append('father_name', father_name);
    formData.append('mother_name', mother_name);
    formData.append('phone_number', phone_number);
    formData.append('wp_number', wp_number);
    formData.append('applied_domain', applied_domain);
    formData.append('specilization', specilization);
    formData.append('email', email);

    const dob = new Date(date_of_birth)

    // calculate month diff from current date
    const month_diff = Date.now() - dob.getTime()

    //convert the calculated difference in date format  
    var age_dt = new Date(month_diff);

    //extract year from date      
    var year = age_dt.getUTCFullYear();

    //now calculate the age of the user  
    var age = Math.abs(year - 1970);


    var emailPattern = /^[^<>()[\]\\,;:\%#^\s@\"$&!@]+@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z0-9]+\.)+[a-zA-Z]{2,}))$/;

    if (name_of_the_candidate === '') {
      alert("Enter your name")
    }
    else if (!name_of_the_candidate.match(/^[A-Za-z][A-Za-z_ ]{7,29}$/)) {
      alert("*Please enter alphabet characters only in your name.")
    }
    else if (father_name === '') {
      alert("*Please enter your father name.")
    }
    else if (!father_name.match(/^[A-Za-z][A-Za-z_ ]{7,29}$/)) {
      alert("*Please enter alphabet characters only in your father name.")
    }
    else if (mother_name === '') {
      alert("*Please enter your mother name.")
    }
    else if (!mother_name.match(/^[A-Za-z][A-Za-z_ ]{7,29}$/)) {
      alert("*Please enter alphabet characters only in your mother name.")
    }
    else if (image === '') {
      alert("Enter your passport size photo")
    }
    else if (image.size > 50000) {
      alert("Image max size 50KB")
    }
    else if (date_of_birth === '') {
      alert("Enter your date of birth")
    }
    else if (age < 18) {
      alert("Please enter a valid date of birth")
    }
    else if (email === '') {
      alert("Enter your email")
    }
    else if (!emailPattern.test(email)) {
      alert("*Please enter valid email-ID.");
    }
    else if (email === candidateEmail) {
      alert("Candidate already registered. Use different email address")
    }
    else if (phone_number === '') {
      alert("Enter your phone_number")
    }
    else if (!phone_number.match(/^[0-9]{10}$/)) {
      alert("*Please enter valid mobile no.");
    }
    else if (wp_number === '') {
      alert("Enter your Whatsapp number")
    }
    else if (!wp_number.match(/^[0-9]{10}$/)) {
      alert("*Please enter valid whatsapp no.");
    }
    else if (applied_domain === '') {
      alert("Enter your Applied Domain")
    }
    else if (!applied_domain.match(/^[A-Za-z][A-Za-z_ ]{2,40}$/)) {
      alert("*Please enter alphabet characters only in your applied domain.")
    }
    else if (specilization === '') {
      alert("Enter your Specilization")
    }
    else if (!specilization.match(/^[A-Za-z][A-Za-z_, ]{2,40}$/)) {
      alert("*Please enter alphabet characters only in your skill. Only used ',' ")
    }else {
      axios.post(`https://candidate.shivila.co/candidate-enrollment/Enrollment/`, formData)
        .then((res) => {
          if (res.status >= 200 && res.status < 300) {
            navigate('/ty', { replace: true });
            alert("Successfully submitted")
            console.log(res)
            setName('')
            setEmail('')
            setFile('')
            setDob('')
            setFather_name('')
            setMother_name('')
            setPhone_number('')
            setWp_number('')
            setApplied_domain('')
            setSpecilization('')
          } else {
            console.log(res.statusText)
          }
        })
        .catch((err) => console.log(err))

      // console.log(data)
    }

   


  };

  return (
    <>
      <p className={style.candidate_page_heading}>Candidate registration</p>
      <div className={style.main_container}>
        <form onSubmit={handleSubmit} className={style.candidate_form}>
          <img src={candidateFormImage} alt="" className={style.candidate_form_image} />
          <div className={style.candidate_form_sub_container}>
            <div className={style.label_box}>
              <input
                type="text"
                name="name_of_the_candidate"
                placeholder="Enter your name"
                onChange={(e) => setName(e.target.value)}
                className={style.form_control}
              />
            </div>
            <div className={style.label_box}>
              <input
                type="file"
                name="image"
                onChange={(e) => setFile(e.target.files[0])}
                className={style.form_control}
              />
              <small className={style.nb}>** You need to add your recent passport size photo here (max size 50KB)</small>
            </div>
            <div className={style.label_box}>
              <input
                type="text"
                name="father_name"
                placeholder="Enter your father name"
                onChange={(e) => setFather_name(e.target.value)}
                className={style.form_control}
              />
            </div>
            <div className={style.label_box}>
              <input
                type="text"
                name="mother_name"
                placeholder="Enter your mother name"
                onChange={(e) => setMother_name(e.target.value)}
                className={style.form_control}
              />
            </div>
            <div className={style.label_box}>
              <input
                type="date"
                name="date_of_birth"
                placeholder="Enter your date of birth"
                onChange={(e) => setDob(e.target.value)}
                className={style.form_control}
              />
            </div>

            <div className={style.label_box}>
              <input
                type="email"
                name="email"
                placeholder="Enter your verified email address"
                onChange={(e) => setEmail(e.target.value)}
                className={style.form_control}
              />
            </div>
            <div className={style.label_box}>
              <input
                type="number"
                name="phone_number"
                placeholder="Enter your mobile number without country code and 0"
                onChange={(e) => setPhone_number(e.target.value)}
                className={style.form_control}
              />
            </div>
            <div className={style.label_box}>
              <input
                type="number"
                name="wp_number"
                placeholder="Enter your whatsapp number without country code and 0"
                onChange={(e) => setWp_number(e.target.value)}
                className={style.form_control}
              />
            </div>
            <div className={style.label_box}>
              <input
                type="text"
                name="applied_domain"
                placeholder="Enter which domain you are applied"
                onChange={(e) => setApplied_domain(e.target.value)}
                className={style.form_control}
              />
            </div>
            <div className={style.label_box}>
              <input
                type="text"
                name="specilization"
                placeholder="Enter your skill. e.g html, css, JS, Java, php"
                onChange={(e) => setSpecilization(e.target.value)}
                className={style.form_control}
              />
            </div>
            <div className={style.label_box}>
              <input
                type="submit"
                value="Submit"
                className={style.submit_candidates_btn}
              />
            </div>
          </div>
        </form>
      </div>
    </>
  );
};

export default Candidate_register_form;
