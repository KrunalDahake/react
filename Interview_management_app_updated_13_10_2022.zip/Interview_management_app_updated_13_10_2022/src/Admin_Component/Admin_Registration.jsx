import React from 'react'
import { useState } from 'react'

// Import CSS
import style from './Admin_login_registration.module.css'

const Admin_Registration = () => {

    const [loginData, setLoginData] = useState({
        full_name: '',
        email: '',
        password: '',
        password2: ''
    })

    const { full_name, email, password, password2 } = loginData;

    const adminOnchange = (e) => {
        const newData = { ...loginData };
        newData[e.target.name] = e.target.value;
        setLoginData(newData);
    }

    const adminRegistrationSubmit = (e) => {
        e.preventDefault();
        const data = {
            full_name, email, password, password2
        }

        const adminRegUrl = `https://admin-reg.ml/admin-accounts/api/register/`;

        if (full_name === '') {
            alert("Enter full_name")
        } else if (email === '') {
            alert("Enter email")
        } else if (password === '') {
            alert("Enter password")
        } else if (password2 === '') {
            alert("Enter password2")
        } else if (password !== password2) {
            alert("Password and confirm password are not same")
        } else {
            fetch(adminRegUrl, {
                method: "POST",
                headers: {
                    'Content-type': 'application/json'
                },
                body: JSON.stringify(data)
            })
                .then((res) => {
                    if (res.ok) {
                        alert('Admin successfully registered')
                    }
                })
                .catch((err) => console.log(err))

        }

        setLoginData({
            full_name: '',
            email: '',
            password: '',
            password2: ''
        })
    }

    return (
        <>
            <form className={style.admin_login_form} onSubmit={adminRegistrationSubmit}>
                <input type="text" name="full_name" id="full_name" onChange={adminOnchange} value={full_name} placeholder="Enter your Name" />
                <input type="email" name="email" id="email" onChange={adminOnchange} value={email} placeholder="Enter your email" />
                <input type="password" name="password" id="password" onChange={adminOnchange} value={password} placeholder="Enter your password" />
                <input type="password" name="password2" id="password2" onChange={adminOnchange} value={password2} placeholder="Enter your confirm password" />
                <input type="submit" value="Register" />
            </form>
        </>
    )
}

export default Admin_Registration