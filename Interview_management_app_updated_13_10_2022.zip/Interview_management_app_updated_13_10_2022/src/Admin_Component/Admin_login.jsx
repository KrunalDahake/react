import React from 'react'
import { useState } from 'react'

// Import CSS
import style from './Admin_login_registration.module.css'

// Import Admin image
import admin_image from '../Image/admin2.png'
import { useNavigate } from 'react-router-dom'

const Admin_login = () => {

    const navigate = useNavigate()

    const [loginData, setLoginData] = useState({
        email: '',
        password: ''
    })

    const { email, password } = loginData;

    const adminOnchange = (e) => {
        const newData = { ...loginData };
        newData[e.target.name] = e.target.value;
        setLoginData(newData);
    }

    const adminLogUrl = `https://admin-reg.ml/admin-accounts/api/login/`;

    const adminLoginSubmit = (e) => {
        e.preventDefault();
        const data = {
            email, password
        }
        console.log(data)

        setLoginData({
            email: '',
            password: '',
        })

        if (email === '') {
            alert("Enter email address")
        } else if (password === '') {
            alert("Enter your password")
        } else {
            fetch(adminLogUrl, {
                method: "POST",
                headers: {
                    'Content-type': 'application/json'
                },
                body: JSON.stringify(data)
            })
                .then((res) => {
                    if (res.ok) {
                        alert("Admin login successfully")
                        navigate('/admin')
                    }
                })
                .catch((err) => console.log(err))
        }


    }


    return (
        <>
            <div className={style.lobby_heading_box}>
                <p className={style.admin_heading}>Admin Login</p>
                <button className={style.goto_home} onClick={() => navigate('/')} ><i class="fa-solid fa-arrow-left"></i> <span className={style.back}>Back</span></button>
            </div>

            <div className={style.form_container}>
                <img src={admin_image} alt="" className={style.admin_image} />
                <form className={style.admin_login_form} onSubmit={adminLoginSubmit}>
                    <input className={style.form_control} type="email" name="email" id="email" onChange={adminOnchange} value={email} placeholder="Enter your email" />
                    <input className={style.form_control} type="password" name="password" id="password" onChange={adminOnchange} value={password} placeholder="Enter your password" />
                    <input type="submit" value="Login" className={style.login_btn} />
                </form>
            </div>
        </>
    )
}

export default Admin_login