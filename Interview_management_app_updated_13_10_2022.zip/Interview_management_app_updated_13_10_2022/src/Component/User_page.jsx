import React from 'react'
import { useParams } from 'react-router-dom'

const User_page = () => {
    const {email} = useParams()
  return (
    <h2>{email}</h2>
  )
}

export default User_page;