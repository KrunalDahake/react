import React, { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom';
import Button_group from '../Button_Group/Button_group';

import { CSVLink, CSVDownload } from 'react-csv'

import style from '../Candidate_page/Candidate_details_page.module.css'
import Admin_details_table from './Admin_details_table';

const Admin = (props) => {

    const { full_name } = useParams()

    // get taken interview student Data
    const candidateUrl = `https://interviewmanagement.shivila.co/candidate-detail/candidate/`;
    const [candidateData, setCandidateData] = useState([])

    const fetchData = async (candidateUrl) => {
        try {
            const response = await fetch(candidateUrl);
            const data = await response.json()
            // console.log(data)
            setCandidateData(data)
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        setInterval(() => {
            fetchData(candidateUrl)
        }, 1000)
    }, [])

    const selected_candidates = candidateData.filter((data) => data.status === 'Selected')
    const not_selected_candidate = candidateData.filter((data) => data.status === 'Not Selected')
    const not_judge_candidate = candidateData.filter((data) => data.status === 'Not Judge')
    const need_second_round = candidateData.filter((data) => data.status === 'Need Second Round')
    // console.log(need_second_round)

    // className={style.previous_page_btn2}

    const [modalOpen, setModalOpen] = useState(false)

    const navigate = useNavigate()


    const candidateDeleteHandeler = (id) => {

        fetch(`https://interviewmanagement.shivila.co/candidate-detail/candidate/${id}/`, {
            method: "DELETE",
            headers: {
                "Content-type": 'application/json',
            }
        })
            .then((res) => {
                if (res.ok) {
                    alert(`${id} no Candidate deleted successfully`)
                } else {
                    alert(`ERROR:- ${res.status}`)
                }
            })
            .catch((err) => console.log(err))
    }



    const [interviewerDetails, setInterviewerDetails] = useState([])

    const url = `https://interviewmanagement.shivila.co/interviewee-reg/register/`;
    // const url = `http://127.0.0.1/interviewee-reg/register/`;
    const fetchData2 = async (url) => {
        try {
            const response = await fetch(url);
            const data = await response.json()
            // console.log(data)
            setInterviewerDetails(data)
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        setInterval(() => {
            fetchData2(url)
        }, 1000)
    }, [])



    const a = interviewerDetails.filter((status) => status.status === '0');
    console.log(a)




    return (
        <>
            <p className={style.interviewdetails}>Interview Details (Admin Section)</p>
            <div className={style.button_box}>
                <button className={style.previous_page_btn} onClick={() => { navigate('/') }}><i class="fa-solid fa-arrow-left"></i> Logout</button>
            </div>
            <div className={style.modal_box_container}>
                <button onClick={() => { setModalOpen(!modalOpen) }} className={style.modal_open_button}>Select download Option</button>
                <div className={style.modal_box}>
                    {
                        modalOpen && <>
                            <CSVLink data={candidateData} className={style.previous_page_btn2}><i class="fa-solid fa-download"></i>&nbsp;  Complete List</CSVLink>
                            <CSVLink data={selected_candidates} className={style.previous_page_btn2}><i class="fa-solid fa-download"></i>&nbsp;  Selected candidate list</CSVLink>
                            <CSVLink data={not_selected_candidate} className={style.previous_page_btn2}><i class="fa-solid fa-download"></i>&nbsp; Not selected candidate List</CSVLink>
                            <CSVLink data={not_judge_candidate} className={style.previous_page_btn2}><i class="fa-solid fa-download"></i>&nbsp; Not judge List</CSVLink>
                            <CSVLink data={need_second_round} className={style.previous_page_btn2}><i class="fa-solid fa-download"></i>&nbsp; Need Second round List</CSVLink>
                        </>
                    }
                </div>
            </div>
            {/* <div className={style.button_box}>
                <select name="" id="">
                    <option value="" onClick={() => { navigate('/seelcted_candidate') }}><button className={style.previous_page_btn} ><i class="fa-solid fa-arrow-left"></i>  Selected Candidate</button></option>
                    <option value=""><button className={style.previous_page_btn} onClick={() => { navigate('/not_seelcted_candidate') }}>Not Selected Candidate <i class="fa-solid fa-arrow-right"></i></button></option>
                    <option value=""><button className={style.previous_page_btn} onClick={() => { navigate('/other_candidate') }}>Others Candidate Status<i class="fa-solid fa-arrow-right"></i></button></option>
                </select>
            </div> */}
            <div className={style.candidate_table_container}>
                <table className={style.candidate_table}>
                    <thead className={style.candidate_table_head}>
                        <tr className={style.candidate_table_tr}>
                            <th className={style.candidate_table_th}>Interviewer Name</th>
                            <th className={style.candidate_table_th}>Candidate name</th>
                            <th className={style.candidate_table_th}>Candidate Email</th>
                            <th className={style.candidate_table_th}>Candidate mobile</th>
                            <th className={style.candidate_table_th}>Candidate Domain</th>
                            <th className={style.candidate_table_th}>Remarks</th>
                            <th className={style.candidate_table_th}>Candidate Status</th>
                            <th className={style.candidate_table_th}>Interview taken time</th>
                            <th className={style.candidate_table_th}>Delete</th>
                            <th className={style.candidate_table_th}>Send Mail</th>
                            <th className={style.candidate_table_th}>Update candidate details</th>
                        </tr>
                    </thead>
                    {
                        candidateData.map((candidate, index) => {
                            return <Admin_details_table candidate={candidate} key={index} candidateDeleteHandeler={candidateDeleteHandeler} />
                        })
                    }

                </table>
            </div>


            <div className={style.candidate_table_container}>
                <table className={style.candidate_table}>
                    <thead className={style.candidate_table_head}>
                        <tr className={style.candidate_table_tr}>
                            <th className={style.candidate_table_th}>Interviewer Name</th>
                            <th className={style.candidate_table_th}>Interviewer Email</th>
                            <th className={style.candidate_table_th}>Interviewer Domain</th>
                            <th className={style.candidate_table_th}>Interviewer status</th>
                        </tr>
                    </thead>
                    <tbody className={style.candidate_table_tbody}>
                        {
                            interviewerDetails.map((data, index) => (
                                <tr className={style.candidate_table_tr2} key={index}>
                                    <td className={style.candidate_table_td}>{data.name}</td>
                                    <td className={style.candidate_table_td}>{data.email}</td>
                                    <td className={style.candidate_table_td}>{data.designation}</td>
                                    <td className={style.candidate_table_td} id={style.status_table} style={data.status === '0' ? {background:'rgb(218, 248, 143)'} : data.status === '1' ? {background:'rgb(255, 80, 80)'} : {background:'aliceblue'}}>{data.status === '0' ? <span className={style.available}>Available <i class="fa-solid fa-check"></i></span> : data.status === '1' ? <span className={style.busy}>Busy <i class="fa-solid fa-circle"></i></span> : <span className={style.offline}>Offline <i class="fa-solid fa-xmark"></i></span>}</td>
                                </tr>
                            ))
                        }

                    </tbody>

                </table>
            </div>



        </>
    )
}

export default Admin