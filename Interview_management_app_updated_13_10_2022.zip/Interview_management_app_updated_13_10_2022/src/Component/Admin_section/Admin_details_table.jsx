import React from 'react'
import { Link } from 'react-router-dom'

import style from '../Candidate_page/Candidate_details_page.module.css'

const Admin_details_table = (props) => {
    const { id, interviewer_name, name_of_the_candidate, email, mobile_number, applied_domain, remarks, status, interview_taken_time } = props.candidate
    // console.log(interviewer_name)


    const deleteHandeler = (id) => {
        //    alert(id)
        props.candidateDeleteHandeler(id)
    }

    const sendMail = () => {
        // const config = {
        //     SecureToken: "aba88a8b-ff7b-41c3-827b-b7a8e8fbf452",
        //     To: email,
        //     From: `sayantan.halder@shivila.com`,
        //     Subject: "Interview Update",
        //     Body: `Your interview result is here and you are selected`


        //     // Host: "smtp.elasticemail.com",
        //     // Username: "recruiting@shivila.com",
        //     // Password: "592D1F64CECC1C4342CBA55B6E5365CE57DF",
        //     // Port:2525,
        //     // To: email,
        //     // From: `sayantan.halder@shivila.com`,
        //     // Subject: "Interview Update",
        //     // Body: `Your interview result is here and you are selected`
        // };

        // if (window.Email) {
        //     window.Email.send(config)
        // }


        // dadar mail
        // const config = {
        //     SecureToken: "428b00f0-0b8f-4a0f-9ef7-457ffd44f1d1",
        //     To: email,
        //     From: `debanka.das@shivila.com`,
        //     Subject: "Interview Update",
        //     Body: `Hello ${name_of_the_candidate},
        //     Your interview result is here. You are ${status}.`
        // };

        // if (window.Email) {
        //     window.Email.send(config)
        //     alert(email)
        // }


        // main*

        // 

        
    }


    return (
        <tbody className={style.candidate_table_tbody}>

            <tr className={style.candidate_table_tr2}>
                <td className={style.candidate_table_td}>{interviewer_name}</td>
                <td className={style.candidate_table_td}>{name_of_the_candidate}</td>
                <td className={style.candidate_table_td}>{email}</td>
                <td className={style.candidate_table_td}>{mobile_number}</td>
                <td className={style.candidate_table_td}>{applied_domain}</td>
                <td className={style.candidate_table_td}>{remarks}</td>
                <td className={style.candidate_table_td}>{status}</td>
                <td className={style.candidate_table_td}>{interview_taken_time}</td>
                <td className={style.candidate_table_td}  ><button className={style.buttonSection} onClick={() => { deleteHandeler(id) }} id={style.deleteButton}>Delete</button></td>
                <td className={style.candidate_table_td}  ><button className={style.buttonSection} onClick={sendMail} id={style.sendMailButton}>Send mail</button></td>
                <td className={style.candidate_table_td}  ><Link to={email} state={{ id, interviewer_name, name_of_the_candidate, email, mobile_number, applied_domain, remarks, status, interview_taken_time }}><button className={style.buttonSection} id={style.updateButton}>update</button></Link></td>
            </tr>
        </tbody>
    )
}

export default Admin_details_table




// aba88a8b-ff7b-41c3-827b-b7a8e8fbf452

