import React, { useState } from 'react'

// Import css
import style from './Interviewer_register_form.module.css'

import interviewer_image from './interviewer_image.png'

const Interviewer_register_form = () => {

    const [interviewerData, setInterviewerData] = useState({
        email: '',
        name: '',
        designation: ''
    })

    const { email, name, designation } = interviewerData;

    const interviewerOnchnage = (e) => {
        const newData = { ...interviewerData };
        newData[e.target.name] = e.target.value
        setInterviewerData(newData)
    }

    const submitInterviewer = (e) => {
        e.preventDefault()

        const data = {
            name, email, designation
        }

        console.log(data)

        const url = `http://127.0.0.1:8000/interviewee-reg/register/`;
        fetch(url, {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(data)
        })
            .then((res) => console.log(res))
            .catch((err) => console.log(err))
    }

    return (
        <>

            <div className={style.lobby_heading_box}>
                <p className={style.interviewerHeading}>Hello Interviewer, Regiser yourself</p>
                <button className={style.goto_home} onClick={() => navigate('/')} ><i class="fa-solid fa-arrow-left"></i> <span className={style.back}>Back</span></button>
            </div>
            <div className={style.main_container}>
                <img src={interviewer_image} alt="" className={style.interviewer_image} />
                <form onSubmit={submitInterviewer} className={style.interviewer_form}>
                    <p className={style.form_heading}>Interviewer register</p>
                    <input required className={style.form_control} placeholder='name' type="name" name="name" id="name" onChange={interviewerOnchnage} value={name} />
                    <input required className={style.form_control} placeholder='email' type="email" name="email" id="email" onChange={interviewerOnchnage} value={email} />
                    <input required className={style.form_control} placeholder='designation' type="designation" name="designation" id="designation" onChange={interviewerOnchnage} value={designation} />
                    <input className={style.submitInterviewer_btn} type="submit" value="Submit" />
                </form>
            </div>
        </>
    )
}

export default Interviewer_register_form