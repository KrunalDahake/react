import React from "react";
import styles from "./card_container.module.css";
import {Link} from 'react-router-dom'


function Card_container(props) {
  return (
    <div className={styles.card_container}>
      <img src={props.image} alt="" className={styles.card_image} />
      <div className={styles.tittle_container}>
        <p className={styles.tittle}>{props.title}</p>
        {/* <p className={styles.para}>{props.para}</p>  */}
      </div>
      {/* <button className={styles.card_button}>{props.card_button}</button> */}
      <div class="wrapper">
        <div class="link_wrapper">
          <Link to={props.link} className={styles.a}>{props.card_button}</Link>
          <div class="icon">
            <i>{props.icon}</i>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Card_container;
