import React from 'react'
import { useState } from 'react'
import Candidate_page from '../Candidate_page/Candidate_page'
import Popup from './Popup'

const Popup_group = () => {
    const [openPopup, setOpenPopup] = useState(false)

    const [data, setData] = useState({
        name: '',
        email: ''
    })
    const [dataStorage, setDataStorage] = useState([])

    const { name, email } = data;

    const onChangeData = (e) => {
        const newData = { ...data }
        newData[e.target.name] = e.target.value;
        setData(newData)
    }
    const saveData = (e) => {
        e.preventDefault()

        const data = {
            name, email
        }
        dataStorage.push(data)
        // console.log(data)
    }

    console.log(dataStorage)


    const updatePopup = (index) =>{
        setOpenPopup(true)
        // console.log(index)
    }
    return (
        <> <form onSubmit={saveData}>
            <input onChange={onChangeData} type="text" name="name" id="name" placeholder='name' />
            <input onChange={onChangeData} type="email" name="email" id="email" placeholder='email' />
            <input type="submit" value='submit' />
        </form>
            {/* <button onClick={() => setOpenPopup(true)}>Open Popup</button> */}
           
            <section>
                {
                    dataStorage.map((data, index) => (
                        <div key={index}>
                            <h1>{data.name}</h1>
                            <h1>{data.email}</h1>
                            <button onClick={updatePopup}>update</button>
                        </div>
                    ))
                }
            </section>

            <Popup trigger={openPopup} setTrigger={setOpenPopup}>
                <form onSubmit={saveData}>
                    <input onChange={onChangeData} type="text" name="name" id="name" placeholder='name' />
                    <input onChange={onChangeData} type="email" name="email" id="email" placeholder='email' />
                    <input type="submit" value='submit' />
                </form>
            </Popup>
        </>
    )
}

export default Popup_group