import React from 'react'

const Popup = (props) => {
  return (props.trigger) ? (
    <div>
        <h1>This is my first popup</h1>
        <button onClick={()=> {props.setTrigger(false)}}>Close popup</button>
        {props.children}
    </div>
  ) : ''
}

export default Popup