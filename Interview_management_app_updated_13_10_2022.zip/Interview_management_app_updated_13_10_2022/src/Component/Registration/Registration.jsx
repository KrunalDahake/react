import React from 'react'

// Import router-dom component
import { Link, useNavigate } from 'react-router-dom'

// Import css
import style from './Registration.module.css'

// Import Login Image
import login_image from './login_image.png'
import { useState } from 'react'

const Registration = () => {
  const navigate = useNavigate()
  // declare useState for registration form
  const [registerData, setRegisterData] = useState({
    full_name: '',
    email: '',
    password: '',
    password2: '',
    designation: '',
  })

  const { full_name, email, password, password2, designation } = registerData;

  const registrationOnchange = (e) => {
    const newData = { ...registerData };
    newData[e.target.name] = e.target.value;
    setRegisterData(newData)
  }

  const registrationSubmit = (e) => {
    e.preventDefault()

    const data = {
      email, full_name, password, password2
    }
    const data2 = {
      name: full_name,
      email,
      designation
    }

    const loginUrl = `https://interviewmanagement-api.ml/accounts/api/register/`;

    var emailPattern = /^[^<>()[\]\\,;:\%#^\s@\"$&!@]+@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z0-9]+\.)+[a-zA-Z]{2,}))$/;

    if (full_name === '') {
      alert("Enter your name")
    } else if (!full_name.match(/^[A-Za-z][A-Za-z_ ]{7,50}$/)) {
      alert("*Please enter alphabet characters only in your name.")
    } else if (email === '') {
      alert("Enter your email")
    } else if (!emailPattern.test(email)) {
      alert("*Please enter valid email-ID.");
    } else if (password !== password2) {
      alert("**Passwords are not same. Please enter same password")
    } else if (designation === '') {
      alert("Please enter your designation")
    } else if (!designation.match(/^[A-Za-z][A-Za-z_ ]{7,29}$/)) {
      alert("*Please enter alphabet characters only in your designation.")
    }
    fetch(loginUrl, {
      method: "POST",
      headers: {
        "Content-type": "application/json"
      },
      body: JSON.stringify(data)
    })
      .then((res) => {
        if (res.ok) {
          alert(`Interviewer registered successFully`)

          fetch(`https://interviewmanagement.shivila.co/interviewee-reg/register/`, {
            method: "POST",
            headers: {
              "Content-type": "application/json"
            },
            body: JSON.stringify(data2)
          })
            .then((res) => console.log(res))
            .catch((err) => console.log(err))

          navigate('/login')
        } else {
          alert(`Use different email address`)
          navigate('/registration')
        }
      })
      .catch((err) => console.log(err))


  }

  const [showPassword, setShowPassword] = useState(false)

  const togglePassword = () => {
    setShowPassword(!showPassword)
  }
  const [showPassword2, setShowPassword2] = useState(false)

  const togglePassword2 = () => {
    setShowPassword2(!showPassword2)
  }



  return (
    <>

      <div className={style.lobby_heading_box}>
        <p className={style.registration_heading}>Interviewer Registration</p>
        <button className={style.goto_home} onClick={() => navigate('/')} ><i class="fa-solid fa-arrow-left"></i> <span className={style.back}>Back</span></button>
      </div>
      <div className={style.main_container}>
        <img src={login_image} alt="" className={style.login_image} />
        <div className={style.registration_container}>
          {/* <img src={shivila_logo} alt="" className={style.shivila_logo} /> */}
          <form onSubmit={registrationSubmit} className={style.registration_form}>
            <p className={style.inner_registration_form_heading}>Register here!</p>
            <input className={style.form_control} type="text" name="full_name" id="full_name" required value={full_name} onChange={registrationOnchange} placeholder="Eneter your name" />
            <input className={style.form_control} type="email" name="email" id="email" required value={email} onChange={registrationOnchange} placeholder='Enter your email' />
            <input className={style.form_control} type="text" name="designation" id="designation" required value={designation} onChange={registrationOnchange} placeholder='Enter your designation' />

            <div className={style.passBox}>
              <input className={style.form_control} type={showPassword ? "text" : "password"} name="password" id="password" required value={password} onChange={registrationOnchange} placeholder='Password' />
              <span onClick={togglePassword} className={style.eyeBtn}>{showPassword ? <i class="fa-solid fa-eye"></i> : <i class="fa-solid fa-eye-slash"></i>}</span>
            </div>
            <div className={style.passBox}>
              <input className={style.form_control} type={showPassword2 ? "text" : "password"} name="password2" id="password2" required value={password2} onChange={registrationOnchange} placeholder='Confirm password' />
              <span onClick={togglePassword2} className={style.eyeBtn}>{showPassword2 ? <i class="fa-solid fa-eye"></i> : <i class="fa-solid fa-eye-slash"></i>}</span>
            </div>
            {/* <Link to={full_name}><input className={style.registrationBtn} type="submit" value="Register" /></Link> */}
            <input className={style.registrationBtn} type="submit" value="Register" />
            <p className={style.last_registration_form_line}>Already have account? <Link to='/login' className={style.goto_login} >click here!</Link></p>
          </form>
        </div>
      </div>
    </>
  )
}

export default Registration;