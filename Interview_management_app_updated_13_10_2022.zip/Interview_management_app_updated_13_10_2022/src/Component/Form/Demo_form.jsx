import React, { useEffect } from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

import style from '../Form/Demo_form.module.css'
import bg from '../img/bg.svg'
import icon from '../img/icon.png'
import Meeting from '../img/Meeting.png'
import wave from '../img/wave.png'

const Demo_form = () => {

  // get useNavigate from react-router-dom
  const navigate = useNavigate()
  const [data, setData] = useState([])

  // Fetching interviewer Data
  const url = `https://interviewmanagement.shivila.co/interviewee-reg/register/`;

  const fetchData = async (url) => {
    try {
      const response = await fetch(url);
      const data = await response.json();
      // console.log(data)
      setData(data)
    } catch (error) {
      console.log(error)
    }
  }

  useEffect(() => {
    fetchData(url)
  }, [])

  // get user data from localstorage
  const interviewer = JSON.parse(localStorage.getItem('user'))

  // filter data from api
  const interviewerData = data.filter((a) => a.email === interviewer.email);

  // Interviewer details
  const name = interviewerData.map((name) => name.name)[0];
  const email = interviewerData.map((email) => email.email)[0];
  const designation = interviewerData.map((designation) => designation.designation)[0]
  const status = interviewerData.map((status) => status.status)[0]
  const id = interviewerData.map((id) => id.id)[0]


  // take useState for link field
  const [interviewer_link, setLink] = useState('')



  // link submit handeler
  const linkSubmit = (e) => {
    e.preventDefault()

    const intervDetails = {
      name, email, designation, status, interviewer_link
    }
    // console.log(intervDetails)
    if (interviewer_link === '') {
      alert("Enter your interview link")
    } else {
      fetch(`https://interviewmanagement.shivila.co/interviewee-reg/register/${id}/`, {
        method: "PUT",
        headers: {
          "Content-type": "application/json"
        },
        body: JSON.stringify(intervDetails)
      })
        .then((res) => {
          if (res.ok) {
            alert("Interviewer's link update successfully")
            navigate('/candidate_page')
          } else {
            alert("Error")
          }
        })
        .catch((err) => console.log(err))
    }
  }
  return (
    <>
      <div className={style.view}>
        <img src={wave} alt="" className={style.wave} />
        <div className={style.Demo_form}>
          <div className={style.bg_img}>
            <img src={bg} alt="" className={style.bg} />
          </div>
          <div className={style.container}>
            <form className={style.link_form} onSubmit={linkSubmit}>
              <img src={icon} alt="" className={style.avatar} />
              <p className={style.heading}>Interview Link</p>
              {/* <input type="url" name="" id="" placeholder="Enter your current intervew Link" className={style.input_field} /> */}
              <input type="url" name="link" id="link" onChange={(e) => setLink(e.target.value)} value={interviewer_link} placeholder="Enter your current intervew Link" className={style.input_field} />
              <input type="submit" value="Submit" className={style.submit_button} />
            </form>
          </div>
        </div>
      </div>
    </>
  )
}

export default Demo_form