import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

import style from './Button_group.module.css'

const Button_group = () => {

    const navigate = useNavigate()




    const interviewerUrl = `https://interviewmanagement.shivila.co/interviewee-reg/register/`;
    const [interviewData, setInterviewerData] = useState([])

    const fetchData2 = async (interviewerUrl) => {
        try {
            const response = await fetch(interviewerUrl);
            const data = await response.json()
            // console.log(data)
            setInterviewerData(data)
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        fetchData2(interviewerUrl)
    }, [])

    const userData = JSON.parse(localStorage.getItem('user'));
    const interviewerName = interviewData.filter((name) => name.email === userData.email)
    const name = interviewerName.map((name) => name.name)[0]
    // const b = a.split('')[0];
    // const name = b[0]
    // console.log(name)



    // Set Interviewer Status Offline
    const interviewerId = interviewerName.map((data) => data.id)[0]
    const interviewerEmail = interviewerName.map((email) => email.email)[0]
    const interviewerDesignation = interviewerName.map((designation) => designation.designation)[0]

    const data = {
        name: name,
        email: interviewerEmail,
        designation: interviewerDesignation,
        status: 2
    }
    // console.log(data)

    const logoutButton = () => {

        fetch(`https://interviewmanagement.shivila.co/interviewee-reg/register/${interviewerId}/`, {
            method: "PUT",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(data)
        })
            .then((res) => {
                if (res.ok) {
                    localStorage.removeItem('user')
                    navigate('/', { replace: true });
                }
            })
            .catch((err) => console.log(err))
    }




    return (
        <div className={style.Button_group_container}>
            <p className={style.interviewerName}><span className={style.welcome}>Welcome to </span><span id={style.interviewerName}>{name}</span></p>
            <div className={style.button_box}>
                <button className={style.button} id={style.logOutBtn} onClick={logoutButton}>Logout</button>
                <button className={style.button} id={style.candidatePage} onClick={() => { navigate('/candidate_details_page') }}>Candidate Details</button>
            </div>
        </div>
    )
}

export default Button_group;