import React from 'react'
import { Link } from 'react-router-dom'


// Import css
import style from './Footer.module.css'

const Footer = () => {
    return (
        <>
            <div className={style.footer_container}>
                <p className={style.footer_text}>Created By @ <Link to='https://shivila.com/'>Shivila Technologies Private Limited</Link> | All Rights Reserved</p>
            </div>
        </>
    )
}

export default Footer