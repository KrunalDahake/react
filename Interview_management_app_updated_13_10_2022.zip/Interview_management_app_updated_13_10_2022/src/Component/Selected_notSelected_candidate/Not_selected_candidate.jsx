



import React from 'react'
import { useEffect } from 'react';
import { useState } from 'react';
import { CSVLink } from 'react-csv';
import { useNavigate } from 'react-router-dom';

import style from '../Candidate_page/Candidate_details_page.module.css'

const Not_selected_candidate = () => {

    const navigate = useNavigate()


    const [selectedCandidate, setSelectedCandidate] = useState([])

    const candidate_url = `https://interview-api.shivila.in/candidate-detail/candidate/`;
    const fetchData = async (candidate_url) => {
        try {
            const response = await fetch(candidate_url);
            const data = await response.json();
            setSelectedCandidate(data)
            console.log(data)
        } catch (error) {

        }
    }

    useEffect(() => {
        fetchData(candidate_url)
    }, [])


    const selectedData = selectedCandidate.filter((data) => data.status === 'Not Selected')
    console.log(selectedData)


    return (
        <>
            <p className={style.selected_candidate_heading}> Not Selected Candidate</p>
            <div className={style.selected_box}>
                <button className={style.previous_page_btn} onClick={() => { navigate('/candidate_details_page') }}><i class="fa-solid fa-arrow-left"></i> Go to Previous page</button>
                <CSVLink data={selectedData} className={style.previous_page_btn2}><i class="fa-solid fa-download"></i>&nbsp; Download Not Selected Candidate</CSVLink>
            </div>
            <div className={style.candidate_table_container}>
                <table className={style.candidate_table}>
                    <thead className={style.candidate_table_head}>
                        <tr className={style.candidate_table_tr}>
                            {/* <th className={style.candidate_table_th}>SL No.</th> */}
                            <th className={style.candidate_table_th}>Interviewer Name</th>
                            <th className={style.candidate_table_th}>Candidate name</th>
                            <th className={style.candidate_table_th}>Candidate Email</th>
                            <th className={style.candidate_table_th}>Candidate mobile</th>
                            <th className={style.candidate_table_th}>Candidate Domain</th>
                            <th className={style.candidate_table_th}>Remarks</th>
                            <th className={style.candidate_table_th}>Candidate Status</th>
                            <th className={style.candidate_table_th}>Interview taken time</th>
                        </tr>
                    </thead>
                    <tbody className={style.candidate_table_tbody}>

                        {
                            selectedData.map((candidate) => (
                                <tr className={style.candidate_table_tr2}>
                                    {/* <td className={style.candidate_table_td}>{candidate.id}</td> */}
                                    <td className={style.candidate_table_td}>{candidate.interviewer_name}</td>
                                    <td className={style.candidate_table_td}>{candidate.name_of_the_candidate}</td>
                                    <td className={style.candidate_table_td}>{candidate.email}</td>
                                    <td className={style.candidate_table_td}>{candidate.mobile_number}</td>
                                    <td className={style.candidate_table_td}>{candidate.applied_domain}</td>
                                    <td className={style.candidate_table_td}>{candidate.remarks}</td>
                                    <td className={style.candidate_table_td}>{candidate.status}</td>
                                    <td className={style.candidate_table_td}>{candidate.interview_taken_time.slice(0, 10)}</td>
                                    {/* <td className={style.candidate_table_td}><button onClick={()=> navigate('/:')}>Update</button></td> */}
                                </tr>
                            ))
                        }

                    </tbody>
                </table>
            </div>
        </>
    )
}

export default Not_selected_candidate