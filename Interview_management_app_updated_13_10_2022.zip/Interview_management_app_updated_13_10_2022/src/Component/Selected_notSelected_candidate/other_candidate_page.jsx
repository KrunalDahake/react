import React from 'react'
import { useEffect } from 'react';
import { useState } from 'react';
import { CSVLink } from 'react-csv';
import { useNavigate } from 'react-router-dom';

import style from '../Candidate_page/Candidate_details_page.module.css'

const Other_candidate_page = () => {

    const navigate = useNavigate()


    const [selectedCandidate, setSelectedCandidate] = useState([])

    const candidate_url = `https://interview-api.shivila.in/candidate-detail/candidate/`;
    const fetchData = async (candidate_url) => {
        try {
            const response = await fetch(candidate_url);
            const data = await response.json();
            setSelectedCandidate(data)
            console.log(data)
        } catch (error) {

        }
    }

    useEffect(() => {
        fetchData(candidate_url)
    }, [])



    const selectedData = selectedCandidate.filter((data) => data.status === 'Not Judge')
    const needSecondRound = selectedCandidate.filter((data) => data.status === 'Need Second Round')


    // Not Judge   Need Second Round

    return (
        <>
            <p className={style.selected_candidate_heading}>Other Candidate Status</p>
            <div className={style.selected_box}>
                <button className={style.previous_page_btn} id={style.previous_page_btn_selected} onClick={() => { navigate('/candidate_details_page') }}><i class="fa-solid fa-arrow-left"></i> Go to Previous page</button>

                <CSVLink data={selectedData} className={style.previous_page_btn2}><i class="fa-solid fa-download"></i>&nbsp; Download Not Judge List</CSVLink>

            </div>
            <p className={style.selected_candidate_heading} id={style.others_candidate_heading}>Not Judge Candidate</p>
            <div className={style.candidate_table_container}>
                <table className={style.candidate_table}>
                    <thead className={style.candidate_table_head}>
                        <tr className={style.candidate_table_tr}>
                            <th className={style.candidate_table_th}>Interviewer Name</th>
                            <th className={style.candidate_table_th}>Candidate name</th>
                            <th className={style.candidate_table_th}>Candidate Email</th>
                            <th className={style.candidate_table_th}>Candidate mobile</th>
                            <th className={style.candidate_table_th}>Candidate Domain</th>
                            <th className={style.candidate_table_th}>Remarks</th>
                            <th className={style.candidate_table_th}>Candidate Status</th>
                            <th className={style.candidate_table_th}>Interview taken time</th>
                        </tr>
                    </thead>
                    <tbody className={style.candidate_table_tbody}>

                        {
                            selectedData.map((candidate) => (
                                <tr className={style.candidate_table_tr2}>
                                    <td className={style.candidate_table_td}>{candidate.interviewer_name}</td>
                                    <td className={style.candidate_table_td}>{candidate.name_of_the_candidate}</td>
                                    <td className={style.candidate_table_td}>{candidate.email}</td>
                                    <td className={style.candidate_table_td}>{candidate.mobile_number}</td>
                                    <td className={style.candidate_table_td}>{candidate.applied_domain}</td>
                                    <td className={style.candidate_table_td}>{candidate.remarks}</td>
                                    <td className={style.candidate_table_td}>{candidate.status}</td>
                                    <td className={style.candidate_table_td}>{candidate.interview_taken_time.slice(0, 10)}</td>
                                </tr>
                            ))
                        }

                    </tbody>
                </table>
            </div>

            <p className={style.selected_candidate_heading} id={style.others_candidate_heading}>Need Second Round</p>
            <div className={style.selected_box}>
                <CSVLink data={needSecondRound} className={style.previous_page_btn2}><i class="fa-solid fa-download"></i>&nbsp; Download NSR list</CSVLink>
            </div>
            <div className={style.candidate_table_container}>
                <table className={style.candidate_table}>
                    <thead className={style.candidate_table_head}>
                        <tr className={style.candidate_table_tr}>
                            <th className={style.candidate_table_th}>Interviewer Name</th>
                            <th className={style.candidate_table_th}>Candidate name</th>
                            <th className={style.candidate_table_th}>Candidate Email</th>
                            <th className={style.candidate_table_th}>Candidate mobile</th>
                            <th className={style.candidate_table_th}>Candidate Domain</th>
                            <th className={style.candidate_table_th}>Remarks</th>
                            <th className={style.candidate_table_th}>Candidate Status</th>
                            <th className={style.candidate_table_th}>Interview taken time</th>
                        </tr>
                    </thead>
                    <tbody className={style.candidate_table_tbody}>

                        {
                            needSecondRound.map((candidate) => (
                                <tr className={style.candidate_table_tr2}>
                                    <td className={style.candidate_table_td}>{candidate.interviewer_name}</td>
                                    <td className={style.candidate_table_td}>{candidate.name_of_the_candidate}</td>
                                    <td className={style.candidate_table_td}>{candidate.email}</td>
                                    <td className={style.candidate_table_td}>{candidate.mobile_number}</td>
                                    <td className={style.candidate_table_td}>{candidate.applied_domain}</td>
                                    <td className={style.candidate_table_td}>{candidate.remarks}</td>
                                    <td className={style.candidate_table_td}>{candidate.status}</td>
                                    <td className={style.candidate_table_td}>{candidate.interview_taken_time.slice(0, 10)}</td>
                                </tr>
                            ))
                        }

                    </tbody>
                </table>
            </div>
        </>
    )
}

export default Other_candidate_page