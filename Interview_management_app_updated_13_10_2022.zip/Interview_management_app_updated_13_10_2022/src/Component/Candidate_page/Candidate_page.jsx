import React, { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom';
import Button_group from '../Button_Group/Button_group';


// Import css
import style from './Candidate.module.css'
import Candidate_form from './Candidate_form';

const Candidate_page = () => {
    const navigate = useNavigate()
    // const {email} = useParams()


    // get register interviewer Data
    // const interviewerUrl = `https://interviewmanagement.shivila.co/interviewee-reg/register/`;
    const interviewerUrl = `https://interviewmanagement.shivila.co/interviewee-reg/register/`;
    const [interviewData, setInterviewerData] = useState([])

    const fetchData2 = async (interviewerUrl) => {
        try {
            const response = await fetch(interviewerUrl);
            const data = await response.json()
            // console.log(data)
            setInterviewerData(data)
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        fetchData2(interviewerUrl)
    }, [])

    const userData = JSON.parse(localStorage.getItem('user'));
    const interviewerName = interviewData.filter((name) => name.email === userData.email)

    // console.log(interviewerName)



    // const interviewerEmail = interviewData.filter((mail)=> mail.email === email)
    // const interviewerName = interviewerEmail.map((intName) => intName.name)[0]

    // console.log(interviewerName)


    const [interviewerStatus, setInterviewerStatus] = useState('')

    const intvrData = interviewData.filter((email) => email.email === userData.email)
    const intvrEmail = intvrData.map((email) => email.email)[0]
    const intvrName = intvrData.map((name) => name.name)[0]
    const intvrdesignation = intvrData.map((designation) => designation.designation)[0]
    const intvrId = intvrData.map((id) => id.id)[0]
    console.log(intvrData)

    const [isModalOpen, setIsModalOpen] = useState(false)
    const [isModalOpen2, setIsModalOpen2] = useState(false)

    const statusHandeler = (e) => {
        e.preventDefault();

        const data = {
            email: intvrEmail,
            name: intvrName,
            designation: intvrdesignation,
            status: interviewerStatus
        }
        // console.log(data)

        if (interviewerStatus === '1') {
            setIsModalOpen(true)
        } else {
            setIsModalOpen(false)
            // setIsModalOpen2(false)
        }

        fetch(`https://interviewmanagement.shivila.co/interviewee-reg/register/${intvrId}/`, {
            method: "PUT",
            headers: {
                'Content-type': 'application/json'
            },
            body: JSON.stringify(data)
        })
            .then((res) => {
                if (res.ok) {
                    alert("Status update successfully")
                }
            })
            .catch((err) => console.log(err))

        setInterviewerStatus('')
    }



    const [regCandData, setRegCandData] = useState('')

    const regCandUrl = `https://candidate.shivila.co/candidate-enrollment/Enrollment/`;

    const fetchData3 = async (regCandUrl) => {
        try {
            const response = await fetch(regCandUrl);
            const data = await response.json()
            // console.log(data)
            setRegCandData(data)
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        fetchData3(regCandUrl)
    }, [])



    const [candidateEmail, setCandidateEmail] = useState('')

    const [candDetails, setCandDetails] = useState([])

    const emailSubmit = (e) => {
        e.preventDefault()
        const details = regCandData.filter((email) => email.email === candidateEmail)
        setCandDetails(details)
        // localStorage.setItem('Candidate', JSON.stringify(details))
        setIsModalOpen2(true)
        // console.log(details)
    }

    // console.log(candDetails)

    const candName = candDetails.map((name) => name.name_of_the_candidate)[0];
    const candEmail = candDetails.map((email) => email.email)[0];
    const candMobile = candDetails.map((mobile) => mobile.phone_number)[0];
    const candDomain = candDetails.map((domain) => domain.applied_domain)[0];
    const candImage = candDetails.map((image)=> image.image)[0]

    const cadDetails = {
        candName, candEmail, candMobile, candDomain, candImage
    }
    console.log(cadDetails)


    // const a  = JSON.parse(localStorage.getItem('Candidate'))
    // const candName = a.map((name)=> name.name_of_the_candidate)[0]
    // const candEmail = a.map((email) => email.email)[0];
    // const candMobile = a.map((mobile) => mobile.phone_number)[0];
    // const candDomain = a.map((domain) => domain.applied_domain)[0];

    // console.log(a)

    // const [candidate, setCandidate] = useState({
    //     name_of_the_candidate: candName,
    //     candidate_email: candEmail,
    //     candidate_mobile_number: candMobile,
    //     applied_domain: candDomain,
    //     remarks: '',
    //     interviewer_name: '',
    //     status: '',
    // })

    // const { name_of_the_candidate, candidate_email, candidate_mobile_number, applied_domain, remarks, interviewer_name, status } = candidate;

    // const candidateOnchange = (e) => {
    //     const newData = { ...candidate };
    //     newData[e.target.name] = e.target.value;
    //     setCandidate(newData)
    // }

    // const candidateOnsubmit = (e) => {
    //     e.preventDefault()

    //     const data = {
    //         name_of_the_candidate,
    //         email: candidate_email,
    //         mobile_number: candidate_mobile_number, applied_domain, remarks, interviewer_name, status
    //     }

    //     console.log(data)



    //     const candidateUrl = `https://interviewmanagement.shivila.co/candidate-detail/candidate/`;

    //     // fetch(candidateUrl, {
    //     //     method: "POST",
    //     //     headers: {
    //     //         "Content-type": "application/json"
    //     //     },
    //     //     body: JSON.stringify(data)
    //     // })
    //     //     .then((res) => {
    //     //         if (res.ok) {
    //     //             alert(`Candidate added successfully`)
    //     //             navigate('/candidate_details_page')
    //     //         } else {
    //     //             alert(`Something went worng!`)
    //     //         }
    //     //     })
    //     //     .catch((err) => console.log(err))


    //     setCandidate({
    //         name_of_the_candidate: '',
    //         candidate_email: '',
    //         candidate_mobile_number: '',
    //         applied_domain: '',
    //         remarks: '',
    //         interviewer_name: '',
    //         status: '',
    //     })

    // }


    return (
        <>
            <div className={style.candidate_page_container}>
                <Button_group />
                <p className={style.candidate_page_heading}>Candidate Form</p>
                <form onSubmit={statusHandeler} className={style.statusForm}>
                    <div className={style.label_box}>
                        <label className={style.status_label}>Set your status</label>
                        <select name="status" id="status" className={style.status_dropdown} onChange={(e) => { setInterviewerStatus(e.target.value) }}>
                            <option>Select your status</option>
                            <option value='0' className={style.available}>Available</option>
                            <option value='1' className={style.busy}>Busy</option>
                        </select>
                        <input type="submit" value="Save" className={style.status_save} />
                    </div>
                </form>
                {
                    isModalOpen && <form className={style.emailform} onSubmit={emailSubmit}>
                        <input className={style.emailField} type="email" name='email' onChange={(e) => { setCandidateEmail(e.target.value) }} placeholder="Enter candidate email" />
                        {/* <Link to={candidateEmail} state={{candName, candEmail,candMobile, candDomain}}><input type="submit" value="Next" /></Link> */}
                        <input type="submit" value="Next" className={style.nextButton} />
                    </form>
                }
                {
                    isModalOpen2 && <Candidate_form cadDetails={cadDetails} />
                }
            </div>
        </>
    )
}

export default Candidate_page



// {
//     isModalOpen2 && <div className={style.main_container}>
//         <form className={style.candidate_form} onSubmit={candidateOnsubmit}>
//             <input required placeholder='Name of the candidate' onChange={candidateOnchange} type="text" name="name_of_the_candidate" value={name_of_the_candidate} id="name_of_the_candidate" className={style.form_control} />
//             <input required placeholder='Candidate email address' onChange={candidateOnchange} type="email" name="candidate_email" value={candidate_email} id="candiate_email" className={style.form_control} />
//             <input required placeholder='Candidate mobile number' onChange={candidateOnchange} type="number" name="candidate_mobile_number" value={candidate_mobile_number} id="candidate_mobile_number" className={style.form_control} />
//             <input required placeholder='Applied domain' onChange={candidateOnchange} type="text" name="applied_domain" id="applied_domain" className={style.form_control} />
//             <input required placeholder='Remarks' onChange={candidateOnchange} type="text" name="remarks" id="remarks" className={style.form_control} />
//             {/* <select name="remarks" id="remarks" onChange={candidateOnchange} className={style.form_control}>
//         <option value="">----------Enter your Remarks---------</option>
//         <option value="Good">Good</option>
//         <option value="Mid Level">Mid Level</option>
//         <option value="Below Level">Below Level</option>
//         <option value="Minus Level">Minus Level</option>
//         <option value="Good in theory">Good in theory</option>
//         <option value="Good in practical">Good in practical</option>
//         <option value="Bad Level">Bad Level</option>
//     </select> */}
//             <select required placeholder='Interviewer name' onChange={candidateOnchange} name="interviewer_name" id="interviewer_name" className={style.form_control}>
//                 <option>-----Select Interviewer name-----</option>
//                 {
//                     interviewerName.map((interviewerName) => (
//                         <option value={interviewerName.name} key={interviewerName.id}>{interviewerName.name}</option>
//                     ))
//                 }
//             </select>
//             <select name="status" id={style.status} onChange={candidateOnchange} className={style.form_control} required value={status}>
//                 <option>------Select Interview Status------</option>
//                 <option value="Selected">Selected</option>
//                 <option value="Not Selected">Not Selected</option>
//                 <option value="Need Second Round">Need Second Round</option>
//                 <option value="Not Judge">Not Judge</option>
//             </select>
//             <input type="submit" value="Submit Candidate" className={style.submit_candidates_btn} />
//         </form>
//     </div>
// }