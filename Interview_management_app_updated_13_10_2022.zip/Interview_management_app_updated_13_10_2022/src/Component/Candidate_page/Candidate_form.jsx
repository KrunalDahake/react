import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'
import { useLocation, useNavigate, useParams } from 'react-router-dom'

import style from '../Candidate_page/Candidate.module.css'

const Candidate_form = (props) => {

    const {
        candName, candEmail, candMobile, candDomain, candImage
    } = props.cadDetails



    // const { email } = useParams()
    const location = useLocation()
    //   console.log(location)
    const navigate = useNavigate()
    // console.log(location)

    const [candidateData, setCandidateData] = useState([])

    const candidate_url = `https://interviewmanagement.shivila.co/candidate-detail/candidate/`;

    const fetchData = async (candidate_url) => {
        try {
            const response = await fetch(candidate_url);
            const data = await response.json()
            // console.log(data)
            setCandidateData(data)
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        fetchData(candidate_url)
    }, [])

    // const candidateEmail = candidateData.filter((can) => can.email === email)
    // const candidateID = candidateEmail.map((candidateId) => candidateId.id)[0]
    // const candidateName = candidateEmail.map((candidateId) => candidateId.name_of_the_candidate)[0]
    // const candidateDomain = candidateEmail.map((candidateId) => candidateId.applied_domain)[0]
    // const candidateRemarks = candidateEmail.map((candidateId) => candidateId.remarks)[0]
    // const candidateStatus = candidateEmail.map((candidateId) => candidateId.status)[0]
    // const candidateMobileNumber = candidateEmail.map((candidateId) => candidateId.mobile_number)[0]
    // console.log(candidateMobileNumber)




    // get register interviewer Data
    const interviewerUrl = `https://interviewmanagement.shivila.co/interviewee-reg/register/`;
    const [interviewData, setInterviewerData] = useState([])

    const fetchData2 = async (interviewerUrl) => {
        try {
            const response = await fetch(interviewerUrl);
            const data = await response.json()
            // console.log(data)
            setInterviewerData(data)
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        fetchData2(interviewerUrl)
    }, [])

    const userData = JSON.parse(localStorage.getItem('user'));
    const interviewerName = interviewData.filter((name) => name.email === userData.email)



    const intvrData = interviewData.filter((email) => email.email === userData.email)
    const intvrEmail = intvrData.map((email) => email.email)[0]
    const intvrName = intvrData.map((name) => name.name)[0]
    const intvrdesignation = intvrData.map((designation) => designation.designation)[0]
    const intvrId = intvrData.map((id) => id.id)[0]

    // console.log(interviewerName)



    const [candidate, setCandidate] = useState({
        name_of_the_candidate: candName,
        candidate_email: candEmail,
        candidate_mobile_number: candMobile,
        applied_domain: candDomain,
        remarks: '',
        interviewer_name: '',
        status: '',
    })

    const { name_of_the_candidate, candidate_email, candidate_mobile_number, applied_domain, remarks, interviewer_name, status } = candidate;

    const candidateOnchange = (e) => {
        const newData = { ...candidate };
        newData[e.target.name] = e.target.value;
        setCandidate(newData)
    }

    const candidateOnsubmit = (e) => {
        e.preventDefault()

        const data = {
            name_of_the_candidate,
            email: candidate_email,
            mobile_number: candidate_mobile_number,
            applied_domain,
            remarks,
            interviewer_name,
            status
        }


        const data2 = {
            email: intvrEmail,
            name: intvrName,
            designation: intvrdesignation,
            status: 0
        }

        // console.log(data2)


        const candidateUrl = `https://interviewmanagement.shivila.co/candidate-detail/candidate/`;

        fetch(candidateUrl, {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(data)
        })
            .then((res) => {
                if (res.ok) {
                    alert(`Candidate added successfully`)
                    navigate('/candidate_details_page')
                    fetch(`https://interviewmanagement.shivila.co/interviewee-reg/register/${intvrId}/`, {
                        method: "PUT",
                        headers: {
                            'Content-type': 'application/json'
                        },
                        body: JSON.stringify(data2)
                    })
                        .then((res) => {
                            if (res.ok) {
                                alert("Status update successfully")
                            }
                        })
                        .catch((err) => console.log(err))
                } else {
                    alert(`Something went worng!`)
                }
            })
            .catch((err) => console.log(err))



        setCandidate({
            name_of_the_candidate: '',
            candidate_email: '',
            candidate_mobile_number: '',
            applied_domain: '',
            remarks: '',
            interviewer_name: '',
            status: '',
        })

    }





    return (
        <div>
            <form className={style.candidate_form} onSubmit={candidateOnsubmit}>
                <img src={candImage} alt="" className={style.candidateImage} />
                <small className={style.declaration}>** I, verified & confirm that uploaded photo and live photo/video are same. <input type="checkbox" name="" id="" required/></small>
                <input required placeholder='Name of the candidate' onChange={candidateOnchange} type="text" name="name_of_the_candidate" value={name_of_the_candidate} id="name_of_the_candidate" className={style.form_control} />
                <input required placeholder='Candidate email address' onChange={candidateOnchange} type="email" name="candidate_email" value={candidate_email} id="candiate_email" className={style.form_control} />
                <input required placeholder='Candidate mobile number' onChange={candidateOnchange} type="number" name="candidate_mobile_number" value={candidate_mobile_number} id="candidate_mobile_number" className={style.form_control} />
                <input required placeholder='Applied domain' onChange={candidateOnchange} type="text" name="applied_domain" id="applied_domain" className={style.form_control} value={applied_domain} />
                {/* <input required placeholder='Remarks' onChange={candidateOnchange} type="text" name="remarks" id="remarks" className={style.form_control} value={remarks} /> */}
                <select name="remarks" id="remarks" onChange={candidateOnchange} className={style.form_control}>
                        <option value="">----------Enter your Remarks---------</option>
                        <option value="Good">Good</option>
                        <option value="Mid_Level">Mid Level</option>
                        <option value="Below_Level">Below Level</option>
                        <option value="Minus_Level">Minus Level</option>
                        <option value="Good_in_theory">Good in theory</option>
                        <option value="Good_in_practical">Good in practical</option>
                        <option value="Not_completed_due_to_some_issue">Not completed due to some issue</option>
                        <option value="Bad_Level">Bad Level</option>
                    </select>
                <select required placeholder='Interviewer name' onChange={candidateOnchange} name="interviewer_name" id="interviewer_name" className={style.form_control}>
                    <option>-----Select Interviewer name-----</option>
                    {
                        interviewerName.map((interviewerName) => (
                            <option value={interviewerName.name} key={interviewerName.id}>{interviewerName.name}</option>
                        ))
                    }
                    {/* <option value={interviewer_name}>{interviewer_name}</option>
          <option value='a'>a</option> */}
                </select>
                <select name="status" id={style.status} onChange={candidateOnchange} className={style.form_control} required value={status}>
                    <option>------Select Interview Status------</option>
                    <option value="Selected">Selected</option>
                    <option value="Not Selected">Not Selected</option>
                    <option value="Need Second Round">Need Second Round</option>
                    <option value="Not Judge">Not Judge</option>
                </select>
                <input type="submit" value="Update Candidate" className={style.submit_candidates_btn} />
            </form>

        </div>
    )
}

export default Candidate_form;