import React, { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom';
import Button_group from '../Button_Group/Button_group';

import { CSVLink, CSVDownload } from 'react-csv'

import style from './Candidate_details_page.module.css'

const Candidate_details_page = () => {

    // const { full_name } = useParams()

    // get taken interview student Data
    const candidateUrl = `https://interviewmanagement.shivila.co/candidate-detail/candidate/`;
    const [candidateData, setCandidateData] = useState([])

    const fetchData = async (candidateUrl) => {
        try {
            const response = await fetch(candidateUrl);
            const data = await response.json()
            // console.log(data)
            setCandidateData(data)
        } catch (error) {
            console.log(error)
        }
    }

    const data = useEffect(() => {
        fetchData(candidateUrl)
    }, [])
    setInterval(data, 1000)



    // className={style.previous_page_btn2}

    const [modalOpen, setModalOpen] = useState(false)

    const navigate = useNavigate()





    const interviewerUrl = `https://interviewmanagement.shivila.co/interviewee-reg/register/`;
    const [interviewData, setInterviewerData] = useState([])

    const fetchData2 = async (interviewerUrl) => {
        try {
            const response = await fetch(interviewerUrl);
            const data = await response.json()
            // console.log(data)
            setInterviewerData(data)
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        fetchData2(interviewerUrl)
    }, [])

    const interviewer = JSON.parse(localStorage.getItem('user'))
    // console.log(interviewer)

    const intervieverEmail = interviewData.filter((mail) => mail.email === interviewer.email)
    const interviewerName = intervieverEmail.map((name) => name.name)[0]

    const interviewerData = candidateData.filter((name) => name.interviewer_name === interviewerName)
    console.log(interviewerData)


    const selected_candidates = interviewerData.filter((data) => data.status === 'Selected')
    const not_selected_candidate = interviewerData.filter((data) => data.status === 'Not Selected')
    const not_judge_candidate = interviewerData.filter((data) => data.status === 'Not Judge')
    const need_second_round = interviewerData.filter((data) => data.status === 'Need Second Round')
    // console.log(need_second_round)





    return (
        <>
            <div className={style.candidate_table_main_container}>
                <p className={style.interviewdetails}>Interview Details</p>
                <div className={style.button_box}>
                    <button className={style.previous_page_btn} onClick={() => { navigate('/candidate_page') }}><i class="fa-solid fa-arrow-left"></i>  Go to previous page</button>
                </div>
                <div className={style.modal_box_container}>
                    <button onClick={() => { setModalOpen(!modalOpen) }} className={style.modal_open_button}>Select download Option</button>
                    <div className={style.modal_box}>
                        {
                            modalOpen && <>
                                {/* <CSVLink data={candidateData} className={style.previous_page_btn2}><i class="fa-solid fa-download"></i>&nbsp;  Complete List</CSVLink> */}
                                <CSVLink data={selected_candidates} className={style.previous_page_btn2}><i class="fa-solid fa-download"></i>&nbsp;  Selected candidate list</CSVLink>
                                <CSVLink data={not_selected_candidate} className={style.previous_page_btn2}><i class="fa-solid fa-download"></i>&nbsp; Not selected candidate List</CSVLink>
                                <CSVLink data={not_judge_candidate} className={style.previous_page_btn2}><i class="fa-solid fa-download"></i>&nbsp; Not judge List</CSVLink>
                                <CSVLink data={need_second_round} className={style.previous_page_btn2}><i class="fa-solid fa-download"></i>&nbsp; Need Second round List</CSVLink>
                            </>
                        }
                    </div>
                </div>
                {/* <div className={style.button_box}>
                <select name="" id="">
                    <option value="" onClick={() => { navigate('/seelcted_candidate') }}><button className={style.previous_page_btn} ><i class="fa-solid fa-arrow-left"></i>  Selected Candidate</button></option>
                    <option value=""><button className={style.previous_page_btn} onClick={() => { navigate('/not_seelcted_candidate') }}>Not Selected Candidate <i class="fa-solid fa-arrow-right"></i></button></option>
                    <option value=""><button className={style.previous_page_btn} onClick={() => { navigate('/other_candidate') }}>Others Candidate Status<i class="fa-solid fa-arrow-right"></i></button></option>
                </select>
            </div> */}
                <div className={style.candidate_table_container}>
                    <table className={style.candidate_table}>
                        <thead className={style.candidate_table_head}>
                            <tr className={style.candidate_table_tr}>
                                <th className={style.candidate_table_th}>Interviewer Name</th>
                                <th className={style.candidate_table_th}>Candidate name</th>
                                <th className={style.candidate_table_th}>Candidate Email</th>
                                <th className={style.candidate_table_th}>Candidate mobile</th>
                                <th className={style.candidate_table_th}>Candidate Domain</th>
                                <th className={style.candidate_table_th}>Remarks</th>
                                <th className={style.candidate_table_th}>Candidate Status</th>
                                <th className={style.candidate_table_th}>Interview taken time</th>
                            </tr>
                        </thead>
                        <tbody className={style.candidate_table_tbody}>

                            {
                                interviewerData.map((candidate, index) => (
                                    <tr className={style.candidate_table_tr2} key={index}>
                                        <td className={style.candidate_table_td}>{candidate.interviewer_name}</td>
                                        <td className={style.candidate_table_td}>{candidate.name_of_the_candidate}</td>
                                        <td className={style.candidate_table_td}>{candidate.email}</td>
                                        <td className={style.candidate_table_td}>{candidate.mobile_number}</td>
                                        <td className={style.candidate_table_td}>{candidate.applied_domain}</td>
                                        <td className={style.candidate_table_td}>{candidate.remarks}</td>
                                        <td className={style.candidate_table_td}>{candidate.status}</td>
                                        <td className={style.candidate_table_td}>{candidate.interview_taken_time.slice(0, 10)}</td>

                                    </tr>
                                ))
                            }

                        </tbody>
                    </table>
                </div>
            </div>
        </>
    )
}

export default Candidate_details_page