import React from 'react'
import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'

// import css
import style from './Login.module.css'

import login_image from '../Registration/login_image.png'

const Login = () => {

    const [loginData, setLoginData] = useState({
        email: '',
        domain: '',
        password: ''
    })

    const { email, password, domain } = loginData;

    const loginOnchange = (e) => {
        const newData = { ...loginData };
        newData[e.target.name] = e.target.value;
        setLoginData(newData)
    }

    const interviewerUrl = `https://interviewmanagement.shivila.co/interviewee-reg/register/`;
    const [interviewData, setInterviewerData] = useState([])

    const fetchData2 = async (interviewerUrl) => {
        try {
            const response = await fetch(interviewerUrl);
            const data = await response.json()
            // console.log(data)
            setInterviewerData(data)
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        fetchData2(interviewerUrl)
    }, [])



    const loginSubmit = (e) => {
        e.preventDefault()
        const iEmail = `${email}${domain}`;

        const interviewerData = interviewData.filter((intvEmail) => intvEmail.email === iEmail);
        const interviewerId = interviewerData.map((data) => data.id)[0]
        const interviewerEmail = interviewerData.map((email) => email.email)[0]
        const interviewerDesignation = interviewerData.map((designation) => designation.designation)[0]
        const interviewername = interviewerData.map((name) => name.name)[0]

        const data = {
            email: iEmail, password
        }
        // console.log(data)
        // console.log(data)

        // setLoginData({
        //     email: '',
        //     password: ''
        // })
        const data2 = {
            name: interviewername,
            email: interviewerEmail,
            designation: interviewerDesignation,
            status: 0
        }
        // console.log(data2)

        const loginUrl = `https://interviewmanagement.shivila.co/accounts/api/login/`;
        fetch(loginUrl, {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(data)
        })
            .then((res) => {
                if (res.ok) {
                    alert(`User Login successFully`)
                    localStorage.setItem('user', JSON.stringify(data))
                    fetch(`https://interviewmanagement.shivila.co/interviewee-reg/register/${interviewerId}/`, {
                        method: "PUT",
                        headers: {
                            "Content-type": "application/json"
                        },
                        body: JSON.stringify(data2)
                    })
                        .then((res) => {
                            if (res.ok) {
                                navigate('/interviewerLink')
                            }
                        })
                        .catch((err) => console.log(err))
                } else {
                    alert(`Invalid Credients`)
                    navigate('/login')
                }
            })
            .catch((err) => console.log(err))
    }

    const navigate = useNavigate()



    // get register interviewer Data
    //     const interviewerUrl = `https://interviewmanagement.shivila.co/interviewee-reg/register/`;
    //     const [interviewData, setInterviewerData] = useState([])

    //     const fetchData2 = async (interviewerUrl) => {
    //         try {
    //             const response = await fetch(interviewerUrl);
    //             const data = await response.json()
    //             console.log(data)
    //             setInterviewerData(data)
    //         } catch (error) {
    //             console.log(error)
    //         }
    //     }

    //     useEffect(() => {
    //         fetchData2(interviewerUrl)
    //     }, [])

    //    const interviewerEmail = interviewData.filter((mail)=> mail.email === email)
    //    console.log(interviewerEmail)

    // const a = localStorage.getItem('user')
    // const b = JSON.parse(a)
    // console.log(b.email)


    const [showPassword, setShowPassword] = useState(false)


    const togglePassword = () => {
        setShowPassword(!showPassword)
    }


    return (
        <>
            <div className={style.lobby_heading_box}>
                <p className={style.login_page_heading}>Interviewer Login</p>
                <button className={style.goto_home} onClick={() => navigate('/')} ><i class="fa-solid fa-arrow-left"></i> <span className={style.back}>Back</span></button>
            </div>

            <div className={style.login_page_main_container}>
                <div className={style.form_container}>
                    <img src={login_image} alt="" className={style.login_image} />
                    <form className={style.form} onSubmit={loginSubmit}>
                        <p className={style.inner_login_form_heading}>Login here!</p>

                        <input className={style.form_control} type="email" name="email" id="email" onChange={loginOnchange} value={email} required placeholder='Enter your email id' />
                        {/* <select name="domain" id=""  onChange={loginOnchange} required>
                                <option>select</option>
                                <option value="@shivila.com">@shivila.com</option>
                            </select> */}

                        <div className={style.passBox}>
                            <input className={style.form_control} type={showPassword ? "text" : "password"} name="password" id="password" onChange={loginOnchange} value={password} required placeholder='Enter your password' />
                            <span onClick={togglePassword} className={style.eyeBtn}>{showPassword ? <i class="fa-solid fa-eye"></i> : <i class="fa-solid fa-eye-slash"></i>}</span>
                        </div>
                        {/* <Link to={full_name}><input className={style.login_button} type="submit" value="Login" /></Link> */}
                        <input className={style.login_button} type="submit" value="Login" />
                        <p className={style.last_login_form_line}>Don't have account? <Link to='/registration' className={style.goto_registration}>click here!</Link></p>
                    </form>
                </div>
            </div>
        </>

    )
}

export default Login;