import React from "react";
import admin from "../../Image/admin.png";
import interview from "../../Image/interview.png";
import lobby_main from "../../Image/lobby_main.png";
import candidate from "../../Image/candidate.png";
import Card_container from "./Card_container";
import styles from "./Dashboard_table.module.css";
import images from './images.png'
import work from './work.png'

function Dashboard_table() {
  return (
    <>
    <div className={styles.dashboard_conatiner_main}>
    <img src={images} alt="" className={styles.img}/>
    <div className={styles.dashboard}>
      <div className={styles.texts}>
        <span className={styles.welcome}>Welcome</span>
        <span className={styles.to}>To</span>
        <span className={styles.heading}>Interview Management</span>
      </div>
      <div className={styles.card_list}>
        <Card_container
          title="Lobby Members"
          image={lobby_main}
          card_button="Go to next "
          para="dwjdhucusbckjbskjxbskjbxkjsbjsbkjb"
          link='/lobby_login'
          id={styles.card1}
          // icon={GrFormNextLink}
        />
        <Card_container
          title="Candidates"
          image={candidate}
          card_button="Go to next "
          para="dwjdhucusbckjbskjxbskjbxkjsbjsbkjb"
          link='/candidate_login'
          id={styles.card2}
        />
        <Card_container
          title="Interviewer"
          image={interview}
          card_button="Go to next "
          para="dwjdhucusbckjbskjxbskjbxkjsbjsbkjb"
          link='/login'
          id={styles.card3}
        />
        <Card_container
          title="Admin"
          image={admin}
          card_button="Go to next "
          para="dwjdhucusbckjbskjxbskjbxkjsbjsbkjb"
          link='/admin_login'
          id={styles.card4}
        />
      </div>
    </div>
    <img src={work} alt="" className={styles.work} />
    </div>
    </>
  );
}

export default Dashboard_table;
