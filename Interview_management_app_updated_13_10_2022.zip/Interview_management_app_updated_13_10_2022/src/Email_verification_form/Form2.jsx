import axios from 'axios';
import React from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom';

// Import css
import style from './Form.module.css'

// Import image
import image from './candidate_verification.png'

const Form2 = () => {

    const navigate = useNavigate()

    const [email, setEmail] = useState('')
    const [otp, setOtp] = useState('');



    const submit = (e) => {
        e.preventDefault()
        // console.log({ email, otp })

        // let formData = new FormData();
        const data = {
            email, otp
        }




        fetch(`http://127.0.0.1:8000/varify/`, {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify({ email, otp })
        }).then((res) => {
            console.log(res.formData)
            if (res.ok) {
                alert(`Registered successfully`)
                navigate('https://interview-candidate-registration.netlify.app/', {replace: true})
            } else {
                alert(`Your otp has been expired`)
            }
        }).catch((err) => console.log(err))
    }
    return (
        <>
            <div className={style.main_container}>
                <p className={style.candidate_email_form_heading}>Verify your self</p>
                <form onSubmit={submit} className={style.candidate_email_form_container}>
                    <img src={image} alt="" className={style.candidate_email_form_image} />
                    <div className={style.candidate_email_form_control}>
                        <input type="email" name="email" id="link" className={style.candidate_form_control} placeholder='Enter your email address' onChange={(e) => setEmail(e.target.value)} value={email} />
                        <input type="text" name="otp" placeholder='Enter OTP' id={style.otp} className={style.candidate_form_control} onChange={(e) => setOtp(e.target.value)} value={otp} maxLength={6}/>
                        <input type="submit" value="Submit" className={style.submit_button} />
                    </div>
                </form>
            </div>
        </>
    )
}

export default Form2


