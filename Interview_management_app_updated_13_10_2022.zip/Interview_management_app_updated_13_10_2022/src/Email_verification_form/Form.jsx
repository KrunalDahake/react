import React from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

// Import css
import style from './Form.module.css'

// Import image
import image from './candidate_verification.png'

const Form = () => {
    const navigate = useNavigate()

    const [email, setEmail] = useState('')
    const linkSubmit = (e) => {
        e.preventDefault()
        // console.log(email)
        const data = { email }
        fetch(`http://127.0.0.1:8000/register/`, {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(data)
        })
            .then((res) => {
                if (!res.ok) {
                    alert("Email alredy registered. Try with different email address")
                    navigate('/emailverification', { replace: true })
                } else {
                    alert("OTP sent to your given email address")
                    navigate('/verification', { replace: true })
                }
            })
            .catch((err) => console.log(err))

        setEmail('')
    }
    return (
        <>
            <div className={style.main_container}>
                <p className={style.candidate_email_form_heading}>Verify your self</p>
                <form onSubmit={linkSubmit} className={style.candidate_email_form_container}>
                    <img src={image} alt="" className={style.candidate_email_form_image} />
                    <div className={style.candidate_email_form_control}>
                        <input type="email" name="email" id="link" className={style.candidate_form_control} placeholder='Enter your valid email address' onChange={(e) => setEmail(e.target.value)} value={email} />
                        <input type="submit" value="Submit" className={style.submit_button} />
                    </div>
                </form>
            </div>
        </>
    )
}





export default Form