import React from 'react'
import { useState } from 'react';

import axios from 'axios';
import { useEffect } from 'react';

const Form = () => {


    const [image, setImage] = useState('')
    const [phone_number, setPhoneNumber] = useState('')
    const [wp_number, setWpNumber] = useState('')

    const imageHandeler = (e) => {
        console.log(e.target.files[0])
        setImage(e.target.files[0])
    }

    const submit = (e) => {
        e.preventDefault()
        let formData = new FormData();
        formData.append("image", image);
        formData.append("phone_number", phone_number);
        formData.append("wp_number", wp_number);


        const data = {
            phone_number, wp_number, image
        }
        if(image.size >50000){
            alert("max size 50kb")
        }else{
            console.log(data)
        }

        

        axios.post(`http://127.0.0.1:8000/candidate-enrollment/Enrollment/`, formData).then((res) => console.log(res)).catch((err) => console.log(err))
    }

    const [data, setData] = useState([]);
    const url = `http://127.0.0.1:8000/candidate-enrollment/Enrollment/`
    const fetchData = async () => {
        try {
            const response = await fetch(url);
            const data = await response.json()
            console.log(data)
            setData(data)
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        fetchData(url)
    }, [])


    return (
        <>
            <form onSubmit={submit}>
                <input type="number" name="phonenumber" id="phonenumber" onChange={(e) => setPhoneNumber(e.target.value)} />
                <input type="number" name="phonenumber" id="phonenumber" onChange={(e) => setWpNumber(e.target.value)} />
                <input type="file" name="image" id="image" onChange={imageHandeler} />
                <input type="submit" value="Submit" />
            </form>

            {
                data.map((details) => (
                    <>
                        <p>{details.phone_number}</p>
                        <img src={details.image} alt="" style={{ width: "300px", height: "300px" }} />
                    </>
                ))
            }
        </>
    )
}

export default Form