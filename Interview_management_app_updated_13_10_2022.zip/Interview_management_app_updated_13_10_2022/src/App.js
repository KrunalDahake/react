import React from 'react';

// Import react-router-dom component
import { Routes, Route } from 'react-router-dom';
import Admin_login from './Admin_Component/Admin_login';
import Admin_Registration from './Admin_Component/Admin_Registration';
import Candidate_login from './Candidate_email_verification_main/Super_Admin';
import Candidate_register_form from './Candidate_form/Candidate_form';

// import component

import Admin from './Component/Admin_section/Admin';
import Candidate_details_page from './Component/Candidate_page/Candidate_details_page';
import Candidate_form from './Component/Candidate_page/Candidate_form';
import Candidate_page from './Component/Candidate_page/Candidate_page';
import Footer from './Component/Footer/Footer';
import Demo_form from './Component/Form/Demo_form';
import Dashboard_table from './Component/Home_page3/Dashboard_table';
// import Dashboard_table from './Component/Home_page/Dashboard_table';
import Login from './Component/Login/Login';
import Popup_group from './Component/Popup/Popup_group';
import Registration from './Component/Registration/Registration';
import Not_selected_candidate from './Component/Selected_notSelected_candidate/Not_selected_candidate';
import Other_candidate_page from './Component/Selected_notSelected_candidate/other_candidate_page';
import Selected_candidate from './Component/Selected_notSelected_candidate/Selected_candidate';
import Update_form from './Component/Update_form/Update_form';
import User_page from './Component/User_page';
import Form from './Email_verification_form/Form';
import Form2 from './Email_verification_form/Form2';
import Interviewer_link from './Interviewer_link';
import Interviewer_availability from './lobby_component/Interviewer_availability/Interviewer_availability';
import Lobby_login from './lobby_component/Lobby/Lobby_login';
import Lobby_register from './lobby_component/Lobby/Lobby_register';
import NewJokes from './Not_found_and_Thankyou/NewJokes';
import NotFound404 from './Not_found_and_Thankyou/NotFound';
import Admin_registration from './Super_Admin_email_verification_main/Admin_registration';
import LogIn from './Super_Admin_email_verification_main/Super_Admin';
import Thankyou from './Thank_you_and_error_page/Thankyou';



function App() {




  return (
    <>
      <Routes>
        <Route path='/' element={<Dashboard_table />} />
        <Route path='/registration' element={<Registration />} />
        <Route path='/login' element={<Login />} />
        <Route path='/interviewerLink' element={<Demo_form />} />
        <Route path='/candidate_page' element={<Candidate_page />} />
        <Route path='/candidate_page/:candidateEmail' element={<Candidate_form />} />
        <Route path='/candidate_details_page' element={<Candidate_details_page />} />
        <Route path='/admin' element={<Admin />} />
        <Route path='/babarsompotti' element={<Admin />} />
        <Route path='/admin/:email' element={< Update_form />} />

        <Route path='/lobby_login' element={<Lobby_login />} />
        <Route path='/lobby_register' element={<Lobby_register />} />
        <Route path='/register_interviewer' element={<Interviewer_availability />} />

        <Route path='/admin_login' element={<LogIn />} />
        <Route path='/admin_reg' element={<Admin_registration />} />
        {/* <Route path='/babarsompotti' element={<Admin_Registration />} /> */}


        <Route path="/candidate_login" element={<Candidate_login />} />
        <Route path="/registerform" element={<Candidate_register_form />} />
        <Route path="/ty" element={<Thankyou />} />
        <Route path="*" element={<NotFound404 />} />


        {/* <Route path='/emailverification' element={<Form/>} />
        <Route path='/verification' element={<Form2/>} /> */}
        <Route path="*" element={<NewJokes />} />
      </Routes>
      <Footer/>
    </>
  );
}

export default App;