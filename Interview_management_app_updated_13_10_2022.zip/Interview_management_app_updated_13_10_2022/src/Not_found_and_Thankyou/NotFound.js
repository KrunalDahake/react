import axios from 'axios';
import React, { Component } from 'react'
import { Link, Navigate } from 'react-router-dom';
import style from './NotFound.module.css'

export class NotFound404 extends Component {
    constructor() {
        super();
        this.state = {
            joke: ''
        };
    }



    componentDidMount() {
        fetch('https://v2.jokeapi.dev/joke/Any?type=single', {
            method: "GET",
            headers: {
                "Content-type": "application/json"
            }
        })
            .then((res) => {
                this.setState({ joke: res.data.joke });
                console.log(res)
            })
            .catch((err)=> console.log(err))
    }

    render() {
        return (
            <>
                <div className={style.all}>
                    <div>Lost? &#129300;</div>
                    <div>Enjoy the following joke, take a breath and return <Link to='/' className={style.link}>Home</Link></div>
                    <div>{this.state.joke}</div>
                    {/* <div className={style.first}>Over Thinking?</div>
                    <div className={style.second}>Lost?</div>
                    <div className={style.third}>In a hurry?</div> */}
                </div>
            </>
        )
    }
}

export class NotFound extends Component {
    render() {
        return (
            <>
                <Navigate to='/404' replace={true} />
            </>
        )
    }
}
export default NotFound404