import React from 'react'
import style from '../Candidate_Fillup/Thankyou.module.css'


const Thankyou = () => {
  return (
    <div className={style.main}>
      <h1 className={style.heading}>Thank You!</h1>

      <br />
      <br />
      <p className={style.para}>You will get a message in you Whatsapp number</p>
    </div>
  )
}

export default Thankyou
