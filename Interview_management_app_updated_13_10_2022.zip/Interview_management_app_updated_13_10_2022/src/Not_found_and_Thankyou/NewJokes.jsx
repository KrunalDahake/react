import React from 'react'
import { useState } from 'react';
import { useEffect } from 'react';

const NewJokes = () => {

    const [jokes, setJokes] = useState([])

    const jokesUrl = `https://v2.jokeapi.dev/joke/Any?type=single`;

    const fetchJokes = async (jokesUrl) => {
        try {
            const response = await fetch(jokesUrl);
            const data = await response.json()
            console.log(data.joke)
            setJokes(data.joke)
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        setInterval(() => {
            fetchJokes(jokesUrl)
        }, 10000)
    }, [])


    return (
        <>
            {jokes}
        </>
    )
}

export default NewJokes